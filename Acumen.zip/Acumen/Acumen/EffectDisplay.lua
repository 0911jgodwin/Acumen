EffectDisplay = class(Turbine.UI.Control)
function EffectDisplay:Constructor()
    Turbine.UI.Control.Constructor( self );
    self:SetSize(Settings.Player.Effects.Size.X+4, Settings.Player.Effects.Size.Y+4)

    self.Effect = Turbine.UI.Lotro.EffectDisplay()
    self.Effect:SetEffect(nil);
    self.Effect:SetParent(self);
    self.Effect:SetSize(Settings.Player.Effects.Size.X+2, Settings.Player.Effects.Size.Y+2);
    self.Effect:SetVisible(true);
    self.Effect:SetPosition(0,-1)
    self.Effect:SetZOrder(-101);

    --This section creates our icon frame and scales the icon.
    self.IconFrame = Turbine.UI.Control();
    self.IconFrame:SetParent( self );
    self.IconFrame:SetBackColor( Turbine.UI.Color( 1, 0, 0, 0 ) );
    self.IconFrame:SetPosition(2,2);
    self.IconFrame:SetVisible(true);
    self.IconFrame:SetZOrder(2);
    self.IconFrame:SetMouseVisible( false );

    self.IconLabel = Turbine.UI.Control();
    self.IconLabel:SetParent(self.IconFrame);
    self.IconLabel:SetMouseVisible(false);
    self.IconLabel:SetSize(32, 32);
    self.IconLabel:SetBackColor(Turbine.UI.Color(0,1,1,1));
    self.IconLabel:SetBlendMode(2);
    self.IconLabel:SetBackColorBlendMode(7);

    local zoomSize = math.floor(32*(1-Settings.Player.Effects.Size.Zoom));
    local zoomOffset = math.floor(-((32*Settings.Player.Effects.Size.Zoom)/2));
    local width = Settings.Player.Effects.Size.X;
    local height = Settings.Player.Effects.Size.Y;

    -- -- Need to center align the image within the Icon window.
    if width >= height then
        local scaleFactor = width / zoomSize;
        local frameWidth = math.floor(zoomSize * scaleFactor);
        local frameHeightDiff = math.floor(frameWidth - height);
        self.IconFrame:SetSize( zoomSize, zoomSize-(frameHeightDiff/scaleFactor) );

        self.IconLabel:SetPosition(zoomOffset, zoomOffset-((frameHeightDiff/scaleFactor)/2));
    elseif width < height then
        local scaleFactor = height / zoomSize;
        local frameHeight = math.floor(zoomSize * scaleFactor);
        local frameWidthDiff = math.floor(frameHeight - width);
        self.IconFrame:SetSize( zoomSize-(frameWidthDiff/scaleFactor), zoomSize );

        self.IconLabel:SetPosition(zoomOffset-((frameWidthDiff/scaleFactor)/2), zoomOffset);
    end

    self.IconFrame:SetStretchMode( 1 );
    self.IconFrame:SetSize(width, height);

    self.StackLabel = TextDisplay();
    self.StackLabel:SetMouseVisible(false);
    self.StackLabel:SetParent(self);
    self.StackLabel:SetSize(self:GetSize());
    self.StackLabel:SetTextAlignment(Settings.Player.Effects.Stack.Anchor);
	self.StackLabel:SetTextScale(Settings.Player.Effects.Stack.Scale);
    self.StackLabel:SetOffset(Settings.Player.Effects.Stack.Offset.X, Settings.Player.Effects.Stack.Offset.Y);
	self.StackLabel:SetZOrder(103);

    self.CooldownLabel = TextDisplay();
    self.CooldownLabel:SetMouseVisible(false);
    self.CooldownLabel:SetParent(self);
    self.CooldownLabel:SetSize(self:GetSize());
    self.CooldownLabel:SetTextAlignment(Settings.Player.Effects.Duration.Anchor);
	self.CooldownLabel:SetTextScale(Settings.Player.Effects.Duration.Scale);
    self.CooldownLabel:SetOffset(Settings.Player.Effects.Duration.Offset.X, Settings.Player.Effects.Duration.Offset.Y);
	self.CooldownLabel:SetZOrder(103);

    self.border = Turbine.UI.Control();
    self.border:SetMouseVisible(false);
    self.border:SetParent(self);
    self.border:SetZOrder(1);
    self.border:SetBackColor(Turbine.UI.Color(0,0,0));
    self.border:SetPosition(1, 1);
    self.border:SetSize(Settings.Player.Effects.Size.X+2, Settings.Player.Effects.Size.Y+2);
    self.border:SetStretchMode(1);

    self.UpdateHandler = function(delta)
		self.duration = self.duration - delta;

        local timeLeft = math.ceil(self.duration);
        if timeLeft == self.currentTime then
            return;
        end
        self.currentTime = timeLeft;
        if self.currentTime <= 0 then
            self.CooldownLabel:SetText("");
        else 
            self.CooldownLabel:SetText(SecondsToMinutes(math.abs(self.currentTime)));
        end
	end
end

function EffectDisplay:SetEffect(effect)
    self.Effect:SetEffect(effect);
    self.IconLabel:SetBackground(effect:GetIcon());
    local index, length = string.find(effect:GetName(), "%d+")
    if index ~= nil then
        self.StackLabel:SetText(string.sub(effect:GetName(), index, length))
    end

    self.duration = effect:GetDuration();
    if self.duration < 600 then
        self.CooldownLabel:SetText(SecondsToMinutes(math.ceil(self.duration)));
        AddCallback(Updater, "Tick", self.UpdateHandler);
    end
end

function EffectDisplay:Unload() 
    self.border:SetParent(nil);
    self.Effect:SetParent(nil);
    self.IconFrame:SetParent(nil);
    self.CooldownLabel:Unload();
    self.StackLabel:Unload();
end

function EffectDisplay:GetEffect()
    return self.Effect:GetEffect();
end

EffectDisplayBasic= class(Turbine.UI.Control)
function EffectDisplayBasic:Constructor()
    Turbine.UI.Control.Constructor( self );
    self:SetSize(28+4, 28+4)

    self.Effect = Turbine.UI.Lotro.EffectDisplay()
    self.Effect:SetEffect(nil);
    self.Effect:SetParent(self);
    self.Effect:SetSize(28+2, 28+2);
    self.Effect:SetVisible(true);
    self.Effect:SetPosition(0,-1)
    self.Effect:SetZOrder(-101);

    --This section creates our icon frame and scales the icon.
    self.IconFrame = Turbine.UI.Control();
    self.IconFrame:SetParent( self );
    self.IconFrame:SetBackColor( Turbine.UI.Color( 1, 0, 0, 0 ) );
    self.IconFrame:SetPosition(2,2);
    self.IconFrame:SetSize(32,32);
    self.IconFrame:SetVisible(true);
    self.IconFrame:SetZOrder(2);
    self.IconFrame:SetMouseVisible( false );

    self.IconLabel = Turbine.UI.Control();
    self.IconLabel:SetParent(self.IconFrame);
    self.IconLabel:SetMouseVisible(false);
    self.IconLabel:SetSize(32, 32);
    self.IconLabel:SetBackColor(Turbine.UI.Color(0,1,1,1));
    self.IconLabel:SetBlendMode(2);
    self.IconLabel:SetBackColorBlendMode(7);

    local zoomSize = math.floor(28*(1-0));
    local zoomOffset = math.floor(-((28*0)/2));
    local width = 28;
    local height = 28;

    -- -- Need to center align the image within the Icon window.
   

    self.IconFrame:SetStretchMode( 1 );
    self.IconFrame:SetSize(width, height);

    self.StackLabel = TextDisplay();
    self.StackLabel:SetMouseVisible(false);
    self.StackLabel:SetParent(self);
    self.StackLabel:SetSize(self:GetSize());
    self.StackLabel:SetTextAlignment(Turbine.UI.ContentAlignment.TopCenter);
	self.StackLabel:SetTextScale(0.3);
    self.StackLabel:SetOffset(0, -4);
	self.StackLabel:SetZOrder(103);

    self.CooldownLabel = TextDisplay();
    self.CooldownLabel:SetMouseVisible(false);
    self.CooldownLabel:SetParent(self);
    self.CooldownLabel:SetSize(self:GetSize());
    self.CooldownLabel:SetTextAlignment(Turbine.UI.ContentAlignment.BottomCenter);
	self.CooldownLabel:SetTextScale(0.3);
    self.CooldownLabel:SetOffset(0, 8);
	self.CooldownLabel:SetZOrder(103);

    self.border = Turbine.UI.Control();
    self.border:SetMouseVisible(false);
    self.border:SetParent(self);
    self.border:SetZOrder(1);
    self.border:SetBackColor(Turbine.UI.Color(0,0,0));
    self.border:SetPosition(1, 1);
    self.border:SetSize(28+2, 28+2);
    self.border:SetStretchMode(1);

    self.UpdateHandler = function(delta)
		self.duration = self.duration - delta;

        local timeLeft = math.ceil(self.duration);
        if timeLeft == self.currentTime then
            return;
        end
        self.currentTime = timeLeft;
        if self.currentTime <= 0 then
            self.CooldownLabel:SetText("");
        else 
            self.CooldownLabel:SetText(SecondsToMinutes(math.abs(self.currentTime)));
        end
	end
end

function EffectDisplayBasic:SetEffect(effect)
    self.Effect:SetEffect(effect);
    self.IconLabel:SetBackground(effect:GetIcon());
    local index, length = string.find(effect:GetName(), "%d+")
    if index ~= nil then
        self.StackLabel:SetText(string.sub(effect:GetName(), index, length))
    end

    self.duration = effect:GetDuration();
    if self.duration < 600 then
        self.CooldownLabel:SetText(SecondsToMinutes(math.ceil(self.duration)));
        AddCallback(Updater, "Tick", self.UpdateHandler);
    end
end

function EffectDisplayBasic:Unload() 
    self.border:SetParent(nil);
    self.Effect:SetParent(nil);
    self.IconFrame:SetParent(nil);
    self.CooldownLabel:Unload();
    self.StackLabel:Unload();
end

function EffectDisplayBasic:GetEffect()
    return self.Effect:GetEffect();
end