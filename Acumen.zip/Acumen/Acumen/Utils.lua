function Clamp(value, min, max)
	local result = math.max(value, min);
	return math.min(result, max);
end

function Round(num, numDecimalPlaces)
    if num then
        local mult = 10^(numDecimalPlaces or 0)
        local number = math.floor(num * mult + 0.5) / mult
        if (number % 1) == 0 and numDecimalPlaces ~= 0 then
            return tostring(number .. ".0")
        else
            return number
        end
    end
end

function FormatNumber(number)
    if number == nil then return 0 end
    local returnString = ""
    if number < 1000 then
        returnString = Round(number, 0)
    elseif number >= 1000 and number < 1000000 then
        returnString = Round((number / 1000), 1) .. "K"
    elseif number >= 1000000 and number < 1000000000 then
        returnString = Round((number / 1000000),1) .. "M"
    elseif number >= 1000000000 and number < 1000000000000 then 
        returnString = Round((number / 1000000000), 1) .. "B"
    elseif number >= 1000000000000 then
        returnString = Round((number / 1000000000000), 1) .. "T"
    else
        returnString = number
    end

    return returnString
end

LerpValue = class()
function LerpValue:Constructor()
	self.value = 0;
	self.target = 0;
	self.rate = 1;
end

function LerpValue:GetValue()
	return self.value;
end

function LerpValue:GetTargetValue()
	return self.target;
end

function LerpValue:SetValue( value )
	self.target = value;
end

function LerpValue:SetValueImmediate( value )
	self.value = value;
	self.target = value;
end

function LerpValue:GetRate()
	return self.rate;
end

function LerpValue:SetRate( rate )
	self.rate = rate;
end

function LerpValue:NeedsUpdate()
	return ( self.value ~= self.target );
end

function LerpValue:Update( delta )
	if ( self.value < self.target ) then
		self.value = self.value + self.rate * delta;

		if ( self.value > self.target ) then
			self.value = self.target;
		end
	elseif ( self.value > self.target ) then

		self.value = self.value - self.rate * delta;

		if ( self.value < self.target ) then
			self.value = self.target;
		end
	end
end

function ConfigureFont()
	local numbers = {};
    for i = 0, 9, 1 do
        numbers[i] = Turbine.UI.Graphic("ExoPlugins/Vitals/Resources/AG" .. i .. ".tga");
    end
    numbers[10] = Turbine.UI.Graphic("ExoPlugins/Vitals/Resources/AGColon.tga");
	return numbers;
end

function ConfigureFontTwo()
	local font = {};
    for i = 0, 9, 1 do
        font[tostring(i)] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/" .. i .. ".tga");
    end
    font['a'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/a.tga");
	font['b'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/b.tga");
	font['c'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/c.tga");
	font['d'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/d.tga");
	font['e'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/e.tga");
	font['f'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/f.tga");
	font['g'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/g.tga");
	font['h'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/h.tga");
	font['i'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/i.tga");
	font['j'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/j.tga");
	font['k'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/k.tga");
	font['l'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/l.tga");
	font['m'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/m.tga");
	font['n'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/n.tga");
	font['o'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/o.tga");
	font['p'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/p.tga");
	font['q'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/q.tga");
	font['r'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/r.tga");
	font['s'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/s.tga");
	font['t'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/t.tga");
	font['u'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/u.tga");
	font['v'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/v.tga");
	font['w'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/w.tga");
	font['x'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/x.tga");
	font['y'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/y.tga");
	font['z'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/z.tga");
	font['A'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CA.tga");
	font['B'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CB.tga");
	font['C'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CC.tga");
	font['D'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CD.tga");
	font['E'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CE.tga");
	font['F'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CF.tga");
	font['G'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CG.tga");
	font['H'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CH.tga");
	font['I'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CI.tga");
	font['J'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CJ.tga");
	font['K'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CK.tga");
	font['L'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CL.tga");
	font['M'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CM.tga");
	font['N'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CN.tga");
	font['O'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CO.tga");
	font['P'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CP.tga");
	font['Q'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CQ.tga");
	font['R'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CR.tga");
	font['S'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CS.tga");
	font['T'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CT.tga");
	font['U'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CU.tga");
	font['V'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CV.tga");
	font['W'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CW.tga");
	font['X'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CX.tga");
	font['Y'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CY.tga");
	font['Z'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/CZ.tga");
	font['('] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/(.tga");
	font[')'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/).tga");
	font[','] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/,.tga");
	font['.'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/..tga");
	font[' '] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/space.tga");
	font['-'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/-.tga");
	font['_'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/_.tga");
	font['\''] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/apostrophe.tga");
	font['!'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/exclamation.tga");
	font['?'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/question.tga");
	font['%'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/percent.tga");
	font['\"'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/quote.tga");
	font['&'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/ampersand.tga");
	font['*'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/asterisk.tga");
	font['\\'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/backslash.tga");
	font['/'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/slash.tga");
	font['^'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/chevron.tga");
	font[':'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/colon.tga");
	font[';'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/semicolon.tga");
	font['{'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/curlyleft.tga");
	font['}'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/curlyright.tga");
	font['='] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/equals.tga");
	font['>'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/greaterthan.tga");
	font['<'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/lessthan.tga");
	font['+'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/plus.tga");
	font['['] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/squarebracketleft.tga");
	font[']'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/squarebracketright.tga");
	font['~'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/tilde.tga");
	font['|'] = Turbine.UI.Graphic("ExoPlugins/Acumen/Resources/Font/verticalslash.tga");
	return font;
end

--https://www.lotro.com/forums/showthread.php?428196-Writing-LoTRO-Lua-Plugins-for-Noobs&p=5784203#post5784203
function AddCallback(object, event, callback)
    if (object[event] == nil) then
        object[event] = callback;
    else
        if (type(object[event]) == "table") then
            table.insert(object[event], callback);
        else
            object[event] = {object[event], callback};
        end
    end
    return callback;
end

function RemoveCallback(object, event, callback)
    if (object[event] == callback) then
        object[event] = nil;
    else
        if (type(object[event]) == "table") then
            local size = table.getn(object[event]);
            for i = 1, size do
                if (object[event][i] == callback) then
                    table.remove(object[event], i);
                    break;
                end
            end
        end
    end
end

function LoadData(Scope, FileName)
	return LoadTable(Turbine.PluginData.Load(Scope, FileName, nil));
end

function SaveData(Scope, FileName, Data)
	Turbine.PluginData.Save(Scope, FileName, SaveTable(Data));
end

function LoadTable(Table)
	if Table == nil then
		return nil;
	end
	local Data = {};
	for key, value in pairs(Table) do
		Data[LoadField(key)] = LoadField(value);
	end
	return Data;
end

function LoadField(Field)
	if type(Field) == "table" then
		return LoadTable(Field);
	elseif type(Field) == "string" then
		if string.find(Field, "<num>") then
			return tonumber(string.sub(Field, string.find(Field, ">") + 1, string.len(Field)));
		elseif string.find(Field, "<color>") then
			return "Test";
		else
			return Field;
		end
	elseif type(Field) == "boolean" then
		return Field;
	end
end

function SaveTable(Table)
	if Table == nil then
		return nil;
	end
	local Data = {};
	for key, value in pairs(Table) do
		Data[SaveField(key)] = SaveField(value);
	end
	return Data;
end

function SaveField(Field)
	if type(Field) == "number" then 
		return ("<num>" .. tostring(Field));
	elseif type(Field) == "table" then
		return SaveTable(Field);
	elseif type(Field) == "string" then
		return Field;
	elseif type(Field) == "boolean" then
		return Field;
	end
end

function CreateHoverFunction(obj)
	local hoverFunction = function() 
		if not obj:IsVisible() then return false end

		local x, y = obj:GetMousePosition();

		local pos_x, pos_y = obj:GetPosition();
		local size_x, size_y = obj:GetSize();

		if x + pos_x >= pos_x and x + pos_x <= pos_x + size_x and y + pos_y >= pos_y and y + pos_y <= pos_y + size_y then
			obj.hover = true;

			return true;
		else
			obj.hover = false;

			return false;
		end
	end

	return hoverFunction;
end

function Debug(STRING)
    if STRING == nil or STRING == "" then return end;
    Turbine.Shell.WriteLine("<rgb=#FF5555>" .. STRING .. "</rgb>");
end

function dump(o)
    if type(o) == 'table' then
        local s = '{\n'
        for k,v in pairs(o) do
                if type(k) ~= 'number' then k = '"'..k..'"' end
                s = s .. '['..k..'] = ' .. dump(v) .. '\n'
        end
        return s .. '}\n'
    else
        return tostring(o)
    end
end


function GetClass(actor)
    local class = actor:GetClass();
    if class == Turbine.Gameplay.Class.Brawler then
        class = "Brawler";
    elseif class == Turbine.Gameplay.Class.Burglar then
        class = "Burglar";
    elseif class == Turbine.Gameplay.Class.Beorning then
        class = "Beorning";
    elseif class == Turbine.Gameplay.Class.Captain then
        class = "Captain";
    elseif class == Turbine.Gameplay.Class.Champion then
        class = "Champion";
    elseif class == Turbine.Gameplay.Class.Guardian then
        class = "Guardian";
    elseif class == Turbine.Gameplay.Class.Hunter then
        class = "Hunter";
    elseif class == Turbine.Gameplay.Class.LoreMaster then
        class = "Loremaster";
    elseif class == Turbine.Gameplay.Class.Minstrel then
        class = "Minstrel";
    elseif class == Turbine.Gameplay.Class.RuneKeeper then
        class = "Runekeeper";
    elseif class == Turbine.Gameplay.Class.Warden then
        class = "Warden";
    end

    return class;
end

function SecondsToMinutes(time)
    local timeString = "";
    local seconds = 0;
    local minutes = 0;
    if time <= 60 then
        timeString = tostring(time);
    else
        seconds = (time % 60);
        minutes = math.floor(time / 60);
        if seconds < 10 then
            seconds = "0" .. seconds;
        end
        timeString = minutes .. ":" .. seconds;
    end

    return timeString;
end

function ColorToTable(color)
	local data = {
		["r"] = color.R,
		["g"] = color.G,
		["b"] = color.B,
		["a"] = color.A,
	};
	return data;
end

function StringToAlignment(string)
	if string == "Top Left" then return Turbine.UI.ContentAlignment.TopLeft
	elseif string == "Top Center" then return Turbine.UI.ContentAlignment.TopCenter
	elseif string == "Top Right" then return Turbine.UI.ContentAlignment.TopRight
	elseif string == "Middle Left" then return Turbine.UI.ContentAlignment.MiddleLeft
	elseif string == "Middle Right" then return Turbine.UI.ContentAlignment.MiddleRight
	elseif string == "Middle Center" then return Turbine.UI.ContentAlignment.MiddleCenter
	elseif string == "Bottom Left" then return Turbine.UI.ContentAlignment.BottomLeft
	elseif string == "Bottom Center" then return Turbine.UI.ContentAlignment.BottomCenter
	elseif string == "Bottom Right" then return Turbine.UI.ContentAlignment.BottomRight end
end

function AlignmentToString(alignment)
	if alignment == Turbine.UI.ContentAlignment.TopLeft then return "Top Left" 
	elseif alignment == Turbine.UI.ContentAlignment.TopCenter then return "Top Center"
	elseif alignment == Turbine.UI.ContentAlignment.TopRight then return "Top Right"
	elseif alignment == Turbine.UI.ContentAlignment.MiddleLeft then return "Middle Left"
	elseif alignment == Turbine.UI.ContentAlignment.MiddleRight then return "Middle Right"
	elseif alignment == Turbine.UI.ContentAlignment.MiddleCenter then return "Middle Center"
	elseif alignment == Turbine.UI.ContentAlignment.BottomLeft then return "Bottom Left"
	elseif alignment == Turbine.UI.ContentAlignment.BottomCenter then return "Bottom Center"
	elseif alignment == Turbine.UI.ContentAlignment.BottomRight then return "Bottom Right"end
end

function TableToColor(table)
	return Turbine.UI.Color(1, table["r"], table["g"], table["b"]);
end

function GenerateDefaultSettings()
    local screenWidth, screenHeight = Turbine.UI.Display:GetSize();

    local settings = {
		Player = {
			Position = {
				X = 0.28802083333333,
				Y = 0.65740740740741,
			},
			Vitals = {
				Morale = {
					Position = {
						X = 0,
						Y = 34,
					},
					Display = "Class Colour",
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
					BubbleDisplay = "Default",
					BubbleColor = {
						["r"] = 0.86,
						["g"] = 0.3,
						["b"] = 1,
						["a"] = 1,
					},
					DreadDisplay = "Default",
					DreadColor = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 0.4,
						["a"] = 1,
					},
					Size = {
						X = 250,
						Y = 32,
					},
					Text = {
						Anchor = Turbine.UI.ContentAlignment.BottomRight,
						Format = "%p | %v",
						Offset = {
							X = 0,
							Y = 0,
						},
						Color = {
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
							["a"] = 1,
						},
						Scale = 0.3,
					},
					BubbleText = {
						Enabled = true,
						Anchor = Turbine.UI.ContentAlignment.MiddleRight,
						Offset = {
							X = -3,
							Y = 2,
						},
						Color = {
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
							["a"] = 1,
						},
						Scale = 0.3,
					}
				},
				Power = {
					Position = {
						X = 0,
						Y = 68,
					},
					Display = "Default",
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
					Size = {
						X = 140,
						Y = 12,
					},
				},
				Text = {
					Format = "%n",
					Anchor = Turbine.UI.ContentAlignment.TopLeft,
					Offset = {
						X = 4,
						Y = -8,
					},
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
					Scale = 0.35,
				}
			},
			Effects = {
				Size = {
					X = 30,
					Y = 22,
					Zoom = 0.3,
				},
				Stack = {
					Anchor = Turbine.UI.ContentAlignment.TopCenter,
					Offset = {
						X = 0,
						Y = -7,
					},
					Scale = 0.35,
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
				},
				Duration = {
					Anchor = Turbine.UI.ContentAlignment.BottomCenter,
					Offset = {
						X = 0,
						Y = 12,
					},
					Scale = 0.35,
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
				},
				Debuffs = {
	
				},
				Buffs = {
	
				},
			}
		},
		Target = {
			Enabled = true,
			Position = {
				X = 0.58177083333333,
				Y = 0.68703703703704,
			},
			Vitals = {
				Text = {
					Format = "%n",
				},
				Morale = {
					Display = "Default",
					Color = {
						["r"] = 1,
						["g"] = 1,
						["b"] = 1,
						["a"] = 1,
					},
					Text = {
						Format = "%v | %p",
					},
				},
				TimeToKill = {
					Enabled = true,
					Anchor = Turbine.UI.ContentAlignment.TopLeft,
					Offset = {
						X = 0,
						Y = -4,
					},
					Scale = 0.25,
					Color = {
						["r"] = 0.62,
						["g"] = 0.74,
						["b"] = 1,
						["a"] = 1,
					},
				},
			},
		},
		Logo = {
			Position = {
				X = 0,
				Y = 0.01,
			},
		},
		Effects = {
			Basic = {
				Enabled = true,
				Position = {
					X = 0.6671875,
					Y = 0.01,
				},
			},
			Buffs = {
				["Motivated"] = true,
				["Test"] = true,
				["Testable"] = true,
				["Testing"] = true,
				["IDOME"] = true,
				["Pinata"] = true,
				["Bleugh"] = true,
			},
			Debuffs = {

			},
		},
	};
    return settings;
end

function GetClassColour(class)
	if class == "Brawler" then
		return Turbine.UI.Color(0.78,0.53,0.33);
	elseif class == "Beorning" then
		return Turbine.UI.Color(0.78, 0.61, 0.43);
	elseif class == "Burglar" then
		return Turbine.UI.Color(0.32, 0.32, 0.32);
	elseif class == "Captain" then	
		return Turbine.UI.Color(0.45,0.31,0.84);
	elseif class == "Champion" then
		return Turbine.UI.Color(0.73, 0.11, 0.14);
	elseif class == "Hunter" then
		return Turbine.UI.Color(0.17, 0.48, 0.22);
	elseif class == "Guardian" then
		return Turbine.UI.Color(0.45, 0.2, 0.15);
	elseif class == "Loremaster" then
		return Turbine.UI.Color(0.25, 0.78, 0.92);
	elseif class == "Minstrel" then
		return Turbine.UI.Color(0.91,0.87,0.33);
	elseif class == "Runekeeper" then
		return Turbine.UI.Color(0.79,0.87,0.41);
	elseif class == "Warden" then
		return Turbine.UI.Color(0.41,0.36,1);
	end
	return Turbine.UI.Color(1,0,0);
end