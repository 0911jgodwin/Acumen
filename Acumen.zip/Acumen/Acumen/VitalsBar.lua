VitalsBar = class( Turbine.UI.Control );
function VitalsBar:Constructor(parent, width, height)
	Turbine.UI.Control.Constructor( self );
	self:SetSize(width, height);

	--This section uses SetStretchMode to work out the pixel size of the given texture so we can scale accordingly.
    local TextureSize = Turbine.UI.Control();
    TextureSize:SetBackground("ExoPlugins/Acumen/Resources/bartexture.tga");
    TextureSize:SetStretchMode(2);
    local baseWidth, baseHeight = TextureSize:GetSize();
    TextureSize = nil;

	self.textureBar = Turbine.UI.Control();
	self.textureBar:SetParent(self);
	self.textureBar:SetSize(baseWidth, baseHeight);
	self.textureBar:SetBackground("ExoPlugins/Acumen/Resources/bartexture.tga");
	self.textureBar:SetStretchMode(1);
	self.textureBar:SetSize(width, height);
	self.textureBar:SetZOrder(101);
	self.textureBar:SetBlendMode(4);

	self.background = Turbine.UI.Control();
	self.background:SetBackColor(Turbine.UI.Color(0.1,0.1,0.1));
	self.background:SetParent(self);
	self.background:SetSize(width, height);

	-- The fill bar is the bar used to represent the current value of the
	-- vital.
	self.currentBar = Turbine.UI.Control();
	self.currentBar:SetParent( self );
	self.currentBar:SetHeight(height);
	self.currentBar:SetBlendMode(4);

	-- The temp bar is an additional bar colored differently used to
	-- represent the additional vital granted due to effects that
	-- increase the max.
	self.tempBar = Turbine.UI.Control();
	self.tempBar:SetParent( self );
	self.tempBar:SetHeight(height);
	self.tempBar:SetBlendMode(4);

	-- The dread bar represents the amount of the vital lost due to
	-- effects that modify the max in a negative way.
	self.dreadBar = Turbine.UI.Control();
	self.dreadBar:SetParent( self );
	self.dreadBar:SetHeight(height);
	self.dreadBar:SetBlendMode(4);

	-- The animation classes for smoothly moving the bars.
	self.current = LerpValue();
	self.max = LerpValue();
	self.baseMax = LerpValue();
	self.tempValue = LerpValue();

	self.text = TextDisplay();
	self.text:SetParent(self);
	self.text:SetTextAlignment(Turbine.UI.ContentAlignment.BottomRight);
	self.text:SetSize(width, height);
	self.text:SetOffset(0, 20);
	self.text:SetTextScale(0.3);
	self.text:SetVisible(false);

	self.format = "%p | %v"

	self.lastUpdate = 0;
end

function VitalsBar:ConfigureTextDisplay(anchor, offset, color, scale, format)
	self.text:SetTextAlignment(anchor);
	self.text:SetPosition(offset.X, offset.Y);
	self.text:SetForeColor(TableToColor(color));
	self.text:SetTextScale(scale);
	self.format = format;
end

function VitalsBar:ConfigureBubbleText(anchor, offset, color, scale)
	self.BubbleText = TextDisplay();
	self.BubbleText:SetParent(self);
	self.BubbleText:SetTextAlignment(anchor);
	self.BubbleText:SetSize(self:GetSize());
	self.BubbleText:SetOffset(offset.X, offset.Y);
	self.BubbleText:SetForeColor(TableToColor(color));
	self.BubbleText:SetTextScale(scale);
	self.BubbleText:SetVisible(false);
end

function VitalsBar:SetTextVisible(bool)
	self.text:SetVisible(bool);
end

function VitalsBar:SetColors( current, temp, dread )
	self.currentBar:SetBackColor( current );
	self.tempBar:SetBackColor( temp );
	self.dreadBar:SetBackColor( dread );
end

function VitalsBar:SetValue( value )
	self.current:SetValue( value );
	self.current:SetRate( self.max:GetTargetValue() / self:GetWidth() * 180 );

	if ( self.current:NeedsUpdate() ) then
		self:SetWantsUpdates( true );
	end
end

function VitalsBar:SetTempValue( value )
	self.tempValue:SetValue( value );
	self.tempValue:SetRate( self.max:GetTargetValue() / self:GetWidth() * 180 );

	if ( self.tempValue:NeedsUpdate() ) then
		self:SetWantsUpdates( true );
	end
end

function VitalsBar:SetMax( value )
	self.max:SetValueImmediate( value );
	self.current:SetRate( self.max:GetTargetValue() / self:GetWidth() * 720 );

	if ( self.max:NeedsUpdate() ) then
		self:SetWantsUpdates( true );
	end
end

function VitalsBar:SetBaseMax( value )
	self.baseMax:SetValueImmediate( value );

	if ( self.baseMax:NeedsUpdate() ) then
		self:SetWantsUpdates( true );
	end
end

function VitalsBar:SetAllValues(current, max, baseMax, temp)
	self.current:SetValueImmediate( current );
	self.max:SetValueImmediate( max );
	self.baseMax:SetValueImmediate( baseMax );
	self.tempValue:SetValueImmediate( temp );
	self:SetWantsUpdates( true );
end

function VitalsBar:GetValue()
	return self.current:GetValue();
end

function VitalsBar:PrintValues()
	Debug(dump(self.current:GetValue()));
	Debug(dump(self.max:GetValue()));
	Debug(dump(self.baseMax:GetValue()));
	Debug(dump(self.tempValue:GetValue()));
end

function VitalsBar:Update( args )
	local delta = 0;
	local currentTime = Turbine.Engine.GetGameTime();

	if ( self.lastUpdate > 0 ) then
		delta = currentTime - self.lastUpdate;
	end

	self.lastUpdate = currentTime;

	self.current:Update( delta );
	self.max:Update( delta );
	self.baseMax:Update( delta );
	self.tempValue:Update( delta );

	local current = math.floor( self.current:GetValue() + 0.5 );
	local max = math.floor( self.max:GetValue() + 0.5 );
	local temp = math.floor( self.tempValue:GetValue() );

	if current >= 0 then
		local percentage = tostring(math.floor( ( current / max * 100 ) + 0.5 )) .. "%%";
		local textFormat = self.format;
		local currentValue = "";
		if current == 0 then
			currentValue = "Dead";
			percentage = "0%";
		else
			currentValue = FormatNumber(current);
		end
		textFormat = string.gsub(textFormat, "%%v", currentValue);
		textFormat = string.gsub(textFormat, "%%p", percentage);
		self.text:SetText( textFormat );
	else
		self.text:SetText("");
	end

	if self.BubbleText ~= nil then
		if temp > 0 then
			self.BubbleText:SetVisible(true);
			self.BubbleText:SetText(FormatNumber(temp));
		else
			self.BubbleText:SetText("");
		end
	end

	self:PerformLayout();

	if ( not ( self.current:NeedsUpdate() or self.max:NeedsUpdate() or self.baseMax:NeedsUpdate() or self.tempValue:NeedsUpdate() ) ) then
		self:SetWantsUpdates( false );
		self.lastUpdate = 0;
	end
end

function VitalsBar:PerformLayout()
	local width, height = self:GetSize();

	local current = self.current:GetValue();
	local max     = self.max:GetValue();
	local baseMax = self.baseMax:GetValue();
	local temp    = self.tempValue:GetValue();

	local baseBarWidthPercent = 1;

	-- Calculate the percentage of the bar that is the base vital display
	-- versus the adjusted display portion for buffs and debuffs.
	if ( max < baseMax ) then
		baseBarWidthPercent = max / baseMax;
	elseif ( baseMax < max ) then
		baseBarWidthPercent = baseMax / max;
	end

	local baseBarFillPercent   = 0;
	local dreadBarFillPercent  = 0;

	-- Calculate the amount of fill for the base bar and the buffed bar.
	if ( max < baseMax ) then
		-- Dread case.
		baseBarFillPercent = current / max;
		dreadBarFillPercent = 1;
	elseif ( current <= baseMax ) then
		baseBarFillPercent = current / baseMax;
	else
		baseBarFillPercent = 1;
		dreadBarFillPercent = ( current - baseMax ) / ( max - baseMax );
	end

	-- Determine the actual layout of the bars now.
	local baseBarLeft      = 0;
	local baseBarMaxWidth  = math.floor( width * baseBarWidthPercent );
	local baseBarWidth     = math.floor( baseBarMaxWidth * baseBarFillPercent );
	local dreadBarLeft     = baseBarMaxWidth;
	local dreadBarWidth    = math.floor( ( width - baseBarWidth ) * dreadBarFillPercent );

	self.currentBar:SetPosition( baseBarLeft, 0 );
	self.currentBar:SetSize( baseBarWidth, height );

	self.dreadBar:SetVisible( false );
	self.tempBar:SetVisible( false );

	if ( max < baseMax ) then
		self.dreadBar:SetVisible( true );
		self.dreadBar:SetPosition( dreadBarLeft, 0 );
		self.dreadBar:SetSize( dreadBarWidth, height );
	end
	
	if (temp > 0) then
		local total = current + temp;
		local moraleWidth = (current / total) * baseBarWidth;
		local tempWidth = (temp / total) * baseBarWidth;

		self.tempBar:SetVisible( true );
		self.currentBar:SetSize(moraleWidth, height);
		self.tempBar:SetSize(tempWidth+1, height);
		self.tempBar:SetPosition(moraleWidth, 0);
	end
end

function VitalsBar:Unload()
	self.tempBar:SetStretchMode(0);
	self.currentBar:SetStretchMode(0);
	self.dreadBar:SetStretchMode(0);
	self.textureBar:SetStretchMode(0);
	self.background:SetStretchMode(0);
	self.text:SetStretchMode(0);
	self.text:Unload();

	self.tempBar = nil;
	self.currentBar = nil;
	self.dreadBar = nil;
	self.textureBar = nil;
	self.background = nil;
	self.text = nil;
	self:SetWantsUpdates(false);
end