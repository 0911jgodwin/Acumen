EffectsTracking = class( Turbine.UI.Window );
function EffectsTracking:Constructor()
	Turbine.UI.Window.Constructor( self );
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	self:SetPosition(Settings.Effects.Basic.Position.X*screenWidth, Settings.Effects.Basic.Position.Y*screenHeight);
	self:SetSize(432,144);
	self:SetMouseVisible(false);
	self.player = Turbine.Gameplay.LocalPlayer.GetInstance();
	self:ConfigureVisuals();
	self.dragbar = DragBar( self, "Acumen Effects" );
end

function EffectsTracking:ConfigureVisuals()
	-- Construct the effects lists
	self.buffsEffectsList = Turbine.UI.ListBox();
	self.buffsEffectsList:SetParent( self );
	self.buffsEffectsList:SetPosition( 0, 0 );
	self.buffsEffectsList:SetSize( 432,144 );
	self.buffsEffectsList:SetOrientation( Turbine.UI.Orientation.Horizontal );
	self.buffsEffectsList:SetMaxItemsPerLine( 8 );
	self.buffsEffectsList:SetMouseVisible( false );

	self.debuffsEffectsList = Turbine.UI.ListBox();
	self.debuffsEffectsList:SetParent( self );
	self.debuffsEffectsList:SetPosition( 0, 0 );
	self.debuffsEffectsList:SetSize( 432,144 );
	self.debuffsEffectsList:SetOrientation( Turbine.UI.Orientation.Horizontal );
	self.debuffsEffectsList:SetMaxItemsPerLine( 8 );
	self.debuffsEffectsList:SetMouseVisible( false );

	local effects = self.player:GetEffects();

	local i;
	for i = 1, effects:GetCount() do
		self:AddEffect( i );
	end

	self:ConfigureCallbacks();
end

function EffectsTracking:ConfigureCallbacks()
	self.EffectsCallbacks = {};
	self.EffectsCallbacks["EffectAdded"] = AddCallback(self.player:GetEffects(), "EffectAdded", function(sender, args) self:AddEffect(args.Index) end);
	self.EffectsCallbacks["EffectRemoved"] = AddCallback(self.player:GetEffects(), "EffectRemoved", function(sender, args) self:RemoveEffect(args.Effect) end);
end

function EffectsTracking:AddEffect(effectIndex)
	local effect = self.player:GetEffects():Get( effectIndex );

	--Create effect and put it inside the effect listboxes
	local effectDisplay = EffectDisplayBasic()
	effectDisplay:SetEffect( effect );

	--Order effects by duration
	local insertionList = nil;
	local effectEndTime = effect:GetStartTime() + effect:GetDuration();

	if ( effectDisplay:GetEffect():IsDebuff() ) then
		insertionList = self.debuffsEffectsList;
	else
		insertionList = self.buffsEffectsList;
	end

	local i = 0;
	local insertAt = -1;

	for i = 1, insertionList:GetItemCount() do
		local testEffect = insertionList:GetItem( i ):GetEffect();
		local testEffectEndTime = testEffect:GetStartTime() + testEffect:GetDuration();

		if ( effectEndTime > testEffectEndTime ) then
			insertAt = i;
			break;
		end
	end

	if ( insertAt == -1 ) then
		insertionList:AddItem( effectDisplay );
	else
		insertionList:InsertItem( insertAt, effectDisplay );
	end

	self:UpdateEffectsLayout();
end

function EffectsTracking:RemoveEffect(effect)
    local i;

	if ( effect:IsDebuff() ) then
		for i = 1, self.debuffsEffectsList:GetItemCount() do
			local effectListItem = self.debuffsEffectsList:GetItem( i ):GetEffect();
			if ( effect == effectListItem ) then
				local effectElement = self.debuffsEffectsList:GetItem( i );
				effectElement:SetVisible( false );
				self.debuffsEffectsList:RemoveItemAt( i );
				break;
			end
		end
	else
		for i = 1, self.buffsEffectsList:GetItemCount() do
			local effectListItem = self.buffsEffectsList:GetItem( i ):GetEffect();
			if ( effect == effectListItem ) then
				local effectElement = self.buffsEffectsList:GetItem( i );
				effectElement:SetVisible( false );
				self.buffsEffectsList:RemoveItemAt( i );
				break;
			end
		end
	end
	
	self:UpdateEffectsLayout();
end

function EffectsTracking:UpdateEffectsLayout()
	--Calculate the height of the buffs bar, if no debuffs present then buffs should be on the top line
	local debuffsCount = self.debuffsEffectsList:GetItemCount();
	local rows = math.ceil( debuffsCount / self.debuffsEffectsList:GetMaxItemsPerLine() );
	local debuffsHeight = ( rows * 22 );
	local buffsTop = ( self.debuffsEffectsList:GetTop() ) + debuffsHeight;
	self.debuffsEffectsList:SetSize( self.debuffsEffectsList:GetWidth(), debuffsHeight );
	self.buffsEffectsList:SetPosition( 0, buffsTop );

	--Calculate the height of the buffs bar, if no debuffs present then buffs should be on the top line
	local buffsCount = self.buffsEffectsList:GetItemCount();
	local rows = math.ceil( debuffsCount / self.buffsEffectsList:GetMaxItemsPerLine() );
	local debuffsHeight = ( rows * 22 );
	local debuffsTop = ( self.buffsEffectsList:GetTop() ) + debuffsHeight;
	self.debuffsEffectsList:SetSize( self.debuffsEffectsList:GetWidth(), debuffsHeight );
	self.buffsEffectsList:SetPosition( 0, buffsTop );
end

function EffectsTracking:RemoveCallbacks()
	for key, value in pairs(self.playerCallbacks) do
        RemoveCallback(self.player, key, value);
        self.playerCallbacks[key] = nil;
    end
	self.playerCallbacks = {};
end

function EffectsTracking:SavePosition()
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	Data = {
		X = self:GetLeft()/screenWidth,
		Y = self:GetTop()/screenHeight,
	};
	Settings.Effects.Basic.Position = Data;
end

function EffectsTracking:Unload()
	self:RemoveCallbacks();
end

function EffectsTracking:Reload()
	self:Unload();
	self:ConfigureVisuals();
	self:ConfigureCallbacks();
end