TargetVitalsWindow = class( Turbine.UI.Window );
function TargetVitalsWindow:Constructor()
	Turbine.UI.Window.Constructor( self );
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	self:SetPosition(Settings.Target.Position.X*screenWidth, Settings.Target.Position.Y*screenHeight);

    -- Time to calculate the size, this will get confusing
	local moraleX = Settings.Player.Vitals.Morale.Size.X + Settings.Player.Vitals.Morale.Position.X;
	local powerX = Settings.Player.Vitals.Power.Size.X + Settings.Player.Vitals.Power.Position.X;

	local moraleY = Settings.Player.Vitals.Morale.Size.Y + Settings.Player.Vitals.Morale.Position.Y;
	local powerY = Settings.Player.Vitals.Power.Size.Y + Settings.Player.Vitals.Power.Position.Y;
    self.effectOffset = math.min(Settings.Player.Vitals.Morale.Position.Y, Settings.Player.Vitals.Power.Position.Y);

	self:SetSize( math.max(moraleX, powerX), math.max(moraleY, powerY)-self.effectOffset );

	-- Grab the player for use with callbacks
	self.player = Turbine.Gameplay.LocalPlayer.GetInstance();
    self.targetCallbacks = {};
    self.playerCallbacks = {};

    self:ConfigureVisuals();
    self:ConfigureCallbacks();

    self.dragbar = DragBar( self, "Acumen Target Vitals" );
end

function TargetVitalsWindow:ConfigureVisuals()
    self.E = Turbine.UI.Lotro.EntityControl();
    self.E:SetParent (self);
    self.E:SetVisible (true);
    self.E:SetSize(self:GetWidth(), self:GetHeight());
    self.E:SetEntity(self.player);
	self.E:SetZOrder(102);

    --Border for the morale bar
	self.moraleBorder = Turbine.UI.Control();
	self.moraleBorder:SetParent(self);
	self.moraleBorder:SetBackColor(Turbine.UI.Color.Black);
	self.moraleBorder:SetPosition((self:GetWidth()-Settings.Player.Vitals.Morale.Size.X)-Settings.Player.Vitals.Morale.Position.X, Settings.Player.Vitals.Morale.Position.Y-self.effectOffset);
	self.moraleBorder:SetSize(Settings.Player.Vitals.Morale.Size.X, Settings.Player.Vitals.Morale.Size.Y);

	self.Name = TextDisplay();
	self.Name:SetParent(self.moraleBorder);
	self.Name:SetSize(self.moraleBorder:GetSize());
	self.Name:SetText(self.player:GetName());
    self.Name:SetForeColor(TableToColor(Settings.Player.Vitals.Text.Color));
	self.Name:SetTextScale(Settings.Player.Vitals.Text.Scale);
	self.Name:SetZOrder(103)
    self.Name:SetTextAlignment(self:MirrorAlignment(Settings.Player.Vitals.Text.Anchor));
	self.Name:SetOffset(-Settings.Player.Vitals.Text.Offset.X, Settings.Player.Vitals.Text.Offset.Y);

    if Settings.Target.Vitals.TimeToKill.Enabled then
        self.TTK = TextDisplay();
        self.TTK:SetParent(self.moraleBorder);
        self.TTK:SetSize(self.moraleBorder:GetSize());
        self.TTK:SetText("");
        self.TTK:SetTextScale(Settings.Target.Vitals.TimeToKill.Scale);
        self.TTK:SetForeColor(TableToColor(Settings.Target.Vitals.TimeToKill.Color));
        self.TTK:SetZOrder(103)
        self.TTK:SetTextAlignment(Settings.Target.Vitals.TimeToKill.Anchor);
        self.TTK:SetOffset(Settings.Target.Vitals.TimeToKill.Offset.X, Settings.Target.Vitals.TimeToKill.Offset.Y);

        self.TTKStartTime = Turbine.Engine.GetGameTime();
        self.TTKStartMorale = 0;
    end

    -- Construct the morale bar.
	self.moraleBar = VitalsBar(self.moraleBorder, self.moraleBorder:GetWidth()-2, self.moraleBorder:GetHeight()-2, true);
	self.moraleBar:SetParent( self.moraleBorder );
	self.moraleBar:SetZOrder( 100 );

    local moraleColor, bubbleColor, dreadColor = Turbine.UI.Color(0.82,0.9,0.1,0.1),Turbine.UI.Color(0.86,0.3,1),Turbine.UI.Color( 1, 1.0, 0.4, 0 );
	if Settings.Target.Vitals.Morale.Display == "Custom" then
		moraleColor = TableToColor(Settings.Target.Vitals.Morale.Color);
	end

	if Settings.Player.Vitals.Morale.BubbleDisplay == "Custom" then
		bubbleColor = TableToColor(Settings.Player.Vitals.Morale.Color);
	end

	if Settings.Player.Vitals.Morale.DreadDisplay == "Custom" then
		dreadColor = TableToColor(Settings.Player.Vitals.Morale.Color);
	end

    self.moraleBar:SetColors( moraleColor, bubbleColor, dreadColor );
	self.moraleBar:SetPosition( 1, 1 );
	self.moraleBar:SetMouseVisible( false );
	self.moraleBar:SetStretchMode(1);

	if Settings.Player.Vitals.Morale.BubbleText.Enabled then
		self.moraleBar:ConfigureBubbleText(
			self:MirrorAlignment(Settings.Player.Vitals.Morale.BubbleText.Anchor),
			self:MirrorOffset(Settings.Player.Vitals.Morale.BubbleText.Offset),
			Settings.Player.Vitals.Morale.BubbleText.Color,
			Settings.Player.Vitals.Morale.BubbleText.Scale
		);
	end

	self.moraleBar:ConfigureTextDisplay(
		self:MirrorAlignment(Settings.Player.Vitals.Morale.Text.Anchor),
		self:MirrorOffset(Settings.Player.Vitals.Morale.Text.Offset),
		Settings.Player.Vitals.Morale.Text.Color,
		Settings.Player.Vitals.Morale.Text.Scale,
		Settings.Target.Vitals.Morale.Text.Format);

    self.moraleBar:SetTextVisible(true);

    --Border for the power bar
	self.powerBorder = Turbine.UI.Control();
	self.powerBorder:SetParent(self);
	self.powerBorder:SetBackColor(Turbine.UI.Color.Black);
    self.powerBorder:SetSize(Settings.Player.Vitals.Power.Size.X, Settings.Player.Vitals.Power.Size.Y);
	self.powerBorder:SetPosition((self:GetWidth()-Settings.Player.Vitals.Power.Size.X)-Settings.Player.Vitals.Power.Position.X, Settings.Player.Vitals.Power.Position.Y-self.effectOffset);

	-- Construct the power bar.
	self.powerBar = VitalsBar(self, self.powerBorder:GetWidth()-2, self.powerBorder:GetHeight()-2);
	self.powerBar:SetParent( self.powerBorder );
	self.powerBar:SetZOrder( 100 );
	if Settings.Player.Vitals.Power.Display == "Custom" then
		self.powerBar:SetColors( TableToColor(Settings.Player.Vitals.Power.Color), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	elseif class == "Beorning" then
		self.powerBar:SetColors( Turbine.UI.Color( 1, 1.0, 0.4, 0 ), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	else
		self.powerBar:SetColors( Turbine.UI.Color( 1, 0, 0.82, 1 ), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	end
	self.powerBar:SetPosition( 1, 1 );
	self.powerBar:SetMouseVisible( false );
	self.powerBar:SetStretchMode(1);
end

function TargetVitalsWindow:MirrorAlignment(alignment)
    if alignment == Turbine.UI.ContentAlignment.TopLeft then alignment = Turbine.UI.ContentAlignment.TopRight
    elseif alignment == Turbine.UI.ContentAlignment.TopRight then alignment = Turbine.UI.ContentAlignment.TopLeft
    elseif alignment == Turbine.UI.ContentAlignment.MiddleLeft then alignment = Turbine.UI.ContentAlignment.MiddleRight
    elseif alignment == Turbine.UI.ContentAlignment.MiddleRight then alignment = Turbine.UI.ContentAlignment.MiddleLeft
    elseif alignment == Turbine.UI.ContentAlignment.BottomLeft then alignment = Turbine.UI.ContentAlignment.BottomRight
    elseif alignment == Turbine.UI.ContentAlignment.BottomRight then alignment = Turbine.UI.ContentAlignment.BottomLeft end
    return alignment;
end

function TargetVitalsWindow:MirrorOffset(offset)
    offset.X = -offset.X;
    offset.Y = offset.Y;
    return offset;
end

function TargetVitalsWindow:ConfigureCallbacks()
    self.playerCallbacks["TargetChanged"] = AddCallback(self.player, "TargetChanged", function(sender, args)
        self:Setup();
    end);

    self:Setup();
end

function TargetVitalsWindow:SetTargetCallbacks()
    self.targetCallbacks["MoraleChanged"] = AddCallback(self.target, "MoraleChanged", function(sender, args) self:UpdateMorale() end);
    self.targetCallbacks["MaxMoraleChanged"] = AddCallback(self.target, "MaxMoraleChanged", function(sender, args) self:SetMorale() end);
    self.targetCallbacks["TemporaryMoraleChanged"] = AddCallback(self.target, "TemporaryMoraleChanged", function(sender, args) self:UpdateMorale() end);
    self.targetCallbacks["PowerChanged"] = AddCallback(self.target, "PowerChanged", function(sender, args) self:UpdatePower() end);
    self.targetCallbacks["MaxPowerChanged"] = AddCallback(self.target, "MaxPowerChanged", function(sender, args) self:SetPower() end);
    self.targetCallbacks["BaseMaxPowerChanged"] = AddCallback(self.target, "BaseMaxPowerChanged", function(sender, args) self:UpdatePower() end);
end

function TargetVitalsWindow:RemoveTargetCallbacks()
    for key, value in pairs(self.targetCallbacks) do
        RemoveCallback(self.target, key, value);
    end
    collectgarbage();
end

function TargetVitalsWindow:RemoveCallbacks()
    self:RemoveTargetCallbacks();
    for key, value in pairs(self.playerCallbacks) do
        RemoveCallback(self.player, key, value);
        self.playerCallbacks[key] = nil;
    end
	if self.CombatCallback ~= nil then
		RemoveCallback(self.player, "InCombatChanged", self.CombatCallback);
	end
end

function TargetVitalsWindow:UpdateMorale()
    -- When a target dies we still get callbacks, check for this and remove
    if not self.target then self:RemoveTargetCallbacks() return end;

    local morale        = self.target:GetMorale();
	local maxMorale     = self.target:GetMaxMorale();
	local tempMorale    = self.target:GetTemporaryMorale();

	self.moraleBar:SetValue( morale );
    self.moraleBar:SetBaseMax( maxMorale );
	self.moraleBar:SetMax( maxMorale );
	self.moraleBar:SetTempValue( tempMorale );

    if Settings.Target.Vitals.TimeToKill.Enabled then
        local currentMorale = self.target:GetMorale();
        local ttk = -math.floor(currentMorale * (self.TTKStartTime-Turbine.Engine.GetGameTime())/(self.TTKStartMorale - currentMorale));
        if ttk < 6000 and ttk > 0 then
            local minutes = math.floor(ttk/60);
            local seconds = math.floor(ttk%60);
            self.TTK:SetText(string.format("%02d:%02d", minutes, seconds));
        else
            self.TTK:SetText("");
        end
    end
end

function TargetVitalsWindow:UpdatePower()
    -- When a target dies we still get callbacks, check for this and remove
    if not self.target then self:RemoveTargetCallbacks() return end;

	local power = self.player:GetPower()
	self.powerBar:SetValue( power );

	local maxPower = self.player:GetMaxPower()
	self.powerBar:SetMax( maxPower );

	local baseMaxPower = self.player:GetBaseMaxPower()
	self.powerBar:SetBaseMax( baseMaxPower );
end

function TargetVitalsWindow:SetMorale()
    local morale        = self.target:GetMorale();
	local maxMorale     = self.target:GetMaxMorale();
	local tempMorale    = self.target:GetTemporaryMorale();

	self.moraleBar:SetAllValues( morale, maxMorale, maxMorale, tempMorale );
    if Settings.Target.Vitals.TimeToKill.Enabled then
        self:ConfigureTTK();
    end
end

function TargetVitalsWindow:ConfigureTTK()
    self.TTKStartTime = Turbine.Engine.GetGameTime();
    self.TTKStartMorale = self.target:GetMorale();
end

function TargetVitalsWindow:SetPower()
    local power        = self.target:GetPower();
    local maxPower = self.target:GetMaxPower();
    local baseMaxPower = self.target:GetBaseMaxPower();

	self.powerBar:SetBaseMax( baseMaxPower );
	self.powerBar:SetMax( maxPower );
	self.powerBar:SetValue( power );
end

function TargetVitalsWindow:Setup()
    if self.target then
        self:RemoveTargetCallbacks();
        self.target = nil;
        self.E:SetEntity(nil);
    end

    self.target = self.player:GetTarget();

    if self.target ~= nil then
        self:SetVisible(true);
        local name, level = self.target:GetName(), 1;
        self.E:SetEntity(self.target);

        if self.target.GetLevel ~= nil then
            local morale, maxMorale, tempMorale, power, maxPower, baseMaxPower = 1,1,0,1,1,1;
            if (self.target:GetLevel() > 1) then
                --NPCs tend to count as level 1
                morale = self.target:GetMorale();
                maxMorale = self.target:GetMaxMorale();
                tempMorale = self.target:GetTemporaryMorale();

                power = self.target:GetPower();
                maxPower = self.target:GetMaxPower();
                baseMaxPower = self.target:GetBaseMaxPower();

                level = self.target:GetLevel();

                self:SetTargetCallbacks();
            end

            -- Weird bug occurs where temp morale gets set to some obscenely high number randomly sometimes
            if (tempMorale > 1000000) then tempMorale = 0; end
            self.moraleBar:SetAllValues(morale, maxMorale, maxMorale, tempMorale);
            self.powerBar:SetAllValues(power, maxPower, baseMaxPower, 0);
            self:ConfigureTTK();
        else
            --Inanimate objects to interact with
            self.moraleBar:SetAllValues(1,1,1,0);
        end

        local nameFormat = Settings.Target.Vitals.Text.Format;
	    nameFormat = string.gsub(nameFormat, "%%n", name);
	    nameFormat = string.gsub(nameFormat, "%%l", level);
        self.Name:SetText(nameFormat, true);
    else
        self:SetVisible(false);
    end
end

function TargetVitalsWindow:SavePosition()
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	Data = {
		X = self:GetLeft()/screenWidth,
		Y = self:GetTop()/screenHeight,
	};
	Settings.Target.Position = Data;
end

function TargetVitalsWindow:Unload()
    self:RemoveCallbacks();
	self.moraleBar:Unload();
	self.moraleBar = nil;
    self.E:SetEntity(nil);
	self.E = nil;
	self.frame:SetStretchMode(0);
	self.frame = nil;
	self:SetStretchMode(0);
end

function TargetVitalsWindow:Reload()
    self:Unload();
    self:ConfigureVisuals();
    self:ConfigureCallbacks();
end

function TargetVitalsWindow:SetInactive()
    self:RemoveCallbacks();
    self:SetVisible(false);
end