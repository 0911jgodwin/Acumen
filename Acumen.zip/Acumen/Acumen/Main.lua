import "ExoPlugins.Acumen";
Font = ConfigureFontTwo();

if LoadData(Turbine.DataScope.Character, "AcumenSettings") ~= nil then
	_G.Settings = LoadData(Turbine.DataScope.Character, "AcumenSettings");
else
	_G.Settings = GenerateDefaultSettings();
end

function LoadPlugin()
	VitalsWindow = VitalsWindow();
	VitalsWindow:SetVisible( true );
	Turbine.UI.Lotro.LotroUI.SetEnabled( Turbine.UI.Lotro.LotroUIElement.Vitals, false );
	Turbine.UI.Lotro.LotroUI.SetEnabled( Turbine.UI.Lotro.LotroUIElement.Target, true );
	if _G.Settings["Target"]["Enabled"] == true then
		TargetVitalsWindow = TargetVitalsWindow();
		Turbine.UI.Lotro.LotroUI.SetEnabled( Turbine.UI.Lotro.LotroUIElement.Target, false );
	end

	if _G.Settings["Effects"]["Basic"]["Enabled"] == true then
		Effects = EffectsTracking();
		Effects:SetVisible(true);
	end
end

function ReloadPlugin()
	Turbine.PluginManager.LoadPlugin( "~AcumenReloader" );
end

local status  = 0;
reloader = Turbine.UI.Control();

function reloader:Update()
	if status == 1 then
        Turbine.PluginManager.UnloadScriptState( "AcumenReloader" );
    elseif status > 1 then
        self:SetWantsUpdates( false );
        reloader = nil;
	end
    status = status + 1;
end

reloader:SetWantsUpdates( true );

Logo = Logo();
Updater = Updater();

LoadPlugin();

plugin.Load=function(sender, args)
	Turbine.Shell.WriteLine("<rgb=#FF5555><" .. plugin:GetName() .. "></rgb> V." .. plugin:GetVersion() .. " loaded.");
end

plugin.Unload=function()
	VitalsWindow:Unload();
	SaveData(Turbine.DataScope.Character, "AcumenSettings", Settings);
	Turbine.Shell.WriteLine("<rgb=#FF5555><Acumen></rgb> Unload Complete");
    Turbine.UI.Lotro.LotroUI.SetEnabled( Turbine.UI.Lotro.LotroUIElement.Vitals, true );
end