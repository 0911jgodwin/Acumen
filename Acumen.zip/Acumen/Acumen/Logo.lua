Logo = class( Turbine.UI.Window );
function Logo:Constructor()
	Turbine.UI.Window.Constructor( self );	
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	self:SetPosition(Settings.Logo.Position.X*screenWidth, Settings.Logo.Position.Y*screenHeight);
	self:SetVisible(true);

	self:SetSize(64, 64);
	self:SetBackground("ExoPlugins/Acumen/Resources/UI/athelasButton.tga");
	self:SetStretchMode(1);
	self:SetSize(48,48);

	self.dragbar = DragBar( self, "Acumen Logo" );
end

function Logo:SavePosition()
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	Data = {
		X = self:GetLeft()/screenWidth,
		Y = self:GetTop()/screenHeight,
	};
	Settings.Logo.Position = Data;
end

function Logo:MouseEnter(sender, args)
	self:SetStretchMode(0);
	self:SetSize(64, 64);
	self:SetBackground("ExoPlugins/Acumen/Resources/UI/athelasButtonHighlight.tga");
	self:SetStretchMode(1);
	self:SetSize(48,48);
end

function Logo:MouseLeave(sender, args)
	self:SetStretchMode(0);
	self:SetSize(64, 64);
	self:SetBackground("ExoPlugins/Acumen/Resources/UI/athelasButton.tga");
	self:SetStretchMode(1);
	self:SetSize(48,48);
end

function Logo:MouseClick(sender, args)
	if MenuPanel == nil then
		local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
		MenuPanel = Options.Menu((screenWidth/2)-200,(screenHeight/2)-200);
	else
		MenuPanel:ToggleVisible();
	end
end