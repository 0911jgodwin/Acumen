TextDisplay = class(Turbine.UI.Control);
function TextDisplay:Constructor()
    Turbine.UI.Control.Constructor(self);
    self:SetMouseVisible(false);

    self.textScale = 1;
    self.alignment = Turbine.UI.ContentAlignment.TopLeft;
    self.XOffset = 0;
    self.YOffset = 0;

    self.container = Turbine.UI.Control();
    self.container:SetParent(self);
    self.container:SetSize(0,54);
    self.container:SetTop(0);
    self.characters = {};

    self.tint = Turbine.UI.Control();
    self.tint:SetParent(self.container);
    self.tint:SetBackColorBlendMode(1);
    self.tint:SetZOrder(101);
    self.tint:SetBackColor(Turbine.UI.Color.White);

    self.currentText = "";
end

function TextDisplay:SetTextScale(number)
    local oldScale = self.textScale;
    self.textScale = number;
    self:SetTextAlignment(self.alignment);
    self:ScaleDisplay(self.container:GetWidth()/oldScale);
end

function TextDisplay:SetForeColor(color)
    self.tint:SetBackColor(color);
end

function TextDisplay:SetOffset(x, y)
    self.XOffset = x;
    self.YOffset = y;
    self:SetTextAlignment(self.alignment);
end

function TextDisplay:SetTextAlignment(alignment)
    self.alignment = alignment;
    if self.alignment == Turbine.UI.ContentAlignment.MiddleCenter or self.alignment == Turbine.UI.ContentAlignment.MiddleRight or self.alignment == Turbine.UI.ContentAlignment.MiddleLeft then 
        self.container:SetTop(((self:GetHeight()/2) - ((54*self.textScale)/2))+self.YOffset);
    elseif self.alignment == Turbine.UI.ContentAlignment.BottomCenter or self.alignment == Turbine.UI.ContentAlignment.BottomRight or self.alignment == Turbine.UI.ContentAlignment.BottomLeft then 
        self.container:SetTop((self:GetHeight() - (54*self.textScale))+self.YOffset);
    else
        self.container:SetTop(self.YOffset);
    end

    local left = self.XOffset;
    if self.alignment == Turbine.UI.ContentAlignment.MiddleCenter or self.alignment == Turbine.UI.ContentAlignment.BottomCenter or self.alignment == Turbine.UI.ContentAlignment.TopCenter then
        left = self.XOffset + ((self:GetWidth()/2) - (self.container:GetWidth())/2);
    elseif self.alignment == Turbine.UI.ContentAlignment.TopRight or self.alignment == Turbine.UI.ContentAlignment.MiddleRight or self.alignment == Turbine.UI.ContentAlignment.BottomRight then
        left = self.XOffset + (self:GetWidth()-(self.container:GetWidth()));
    end
    self.container:SetLeft(left);
end

function TextDisplay:SetText(text, sanitise)
    if text == self.currentText then return end
    if sanitise then text = self:SanitiseInput(text) end
    self.currentText = text;
    self:UnloadCharacters();
    local position = 0;

    for c in text:gmatch"." do
        local new = Turbine.UI.Control();
        new:SetPosition(position, 0);
        new:SetParent(self.container);
        new:SetStretchMode(0);
        new:SetBackground(Font[c])
        new:SetStretchMode(2);
        new:SetVisible(true);
        new:SetStretchMode(0);
        position = position+new:GetWidth();
        table.insert(self.characters, new);
    end

    self:ScaleDisplay(position);
end

function TextDisplay:SanitiseInput(str)
    local tableAccents = {}
    tableAccents["À"] = "A"
    tableAccents["Á"] = "A"
    tableAccents["Â"] = "A"
    tableAccents["Ã"] = "A"
    tableAccents["Ä"] = "A"
    tableAccents["Å"] = "A"
    tableAccents["Æ"] = "AE"
    tableAccents["Ç"] = "C"
    tableAccents["È"] = "E"
    tableAccents["É"] = "E"
    tableAccents["Ê"] = "E"
    tableAccents["Ë"] = "E"
    tableAccents["Ì"] = "I"
    tableAccents["Í"] = "I"
    tableAccents["Î"] = "I"
    tableAccents["Ï"] = "I"
    tableAccents["Ð"] = "D"
    tableAccents["Ñ"] = "N"
    tableAccents["Ò"] = "O"
    tableAccents["Ó"] = "O"
    tableAccents["Ô"] = "O"
    tableAccents["Õ"] = "O"
    tableAccents["Ö"] = "O"
    tableAccents["Ø"] = "O"
    tableAccents["Ù"] = "U"
    tableAccents["Ú"] = "U"
    tableAccents["Û"] = "U"
    tableAccents["Ü"] = "U"
    tableAccents["Ý"] = "Y"
    tableAccents["Þ"] = "P"
    tableAccents["ß"] = "s"
    tableAccents["à"] = "a"
    tableAccents["á"] = "a"
    tableAccents["â"] = "a"
    tableAccents["ã"] = "a"
    tableAccents["ä"] = "a"
    tableAccents["å"] = "a"
    tableAccents["æ"] = "ae"
    tableAccents["ç"] = "c"
    tableAccents["è"] = "e"
    tableAccents["é"] = "e"
    tableAccents["ê"] = "e"
    tableAccents["ë"] = "e"
    tableAccents["ì"] = "i"
    tableAccents["í"] = "i"
    tableAccents["î"] = "i"
    tableAccents["ï"] = "i"
    tableAccents["ð"] = "eth"
    tableAccents["ñ"] = "n"
    tableAccents["ò"] = "o"
    tableAccents["ó"] = "o"
    tableAccents["ô"] = "o"
    tableAccents["õ"] = "o"
    tableAccents["ö"] = "o"
    tableAccents["ø"] = "o"
    tableAccents["ù"] = "u"
    tableAccents["ú"] = "u"
    tableAccents["û"] = "u"
    tableAccents["ü"] = "u"
    tableAccents["ý"] = "y"
    tableAccents["þ"] = "p"
    tableAccents["ÿ"] = "y"

  local normalisedString = ''

  local normalisedString = str: gsub("[%z\1-\127\194-\244][\128-\191]*", tableAccents)

  return normalisedString
end

function TextDisplay:ChangeSize()
    self:SetTextAlignment(self.alignment);
    self:ScaleDisplay(self.container:GetWidth()/self.textScale);
end

function TextDisplay:SetImage(control, number)
    control:SetStretchMode(0);
    control:SetBackground(AGFont[tonumber(number)])
    control:SetStretchMode(2);
    control:SetVisible(true);
    control:SetStretchMode(0);
end

function TextDisplay:ScaleDisplay(width)
    self.container:SetStretchMode(0);
    self.container:SetWidth(width);

    self.tint:SetSize(self.container:GetSize());

    self.container:SetStretchMode(1);
    self.container:SetSize(self.container:GetWidth()*self.textScale, 54*self.textScale);

    if self.alignment == Turbine.UI.ContentAlignment.MiddleCenter or self.alignment == Turbine.UI.ContentAlignment.BottomCenter or self.alignment == Turbine.UI.ContentAlignment.TopCenter then
        self.container:SetLeft(self.XOffset + ((self:GetWidth()/2) - (width*self.textScale)/2));
    elseif self.alignment == Turbine.UI.ContentAlignment.TopRight or self.alignment == Turbine.UI.ContentAlignment.MiddleRight or self.alignment == Turbine.UI.ContentAlignment.BottomRight then
        self.container:SetLeft(self.XOffset + (self:GetWidth()-(width*self.textScale)));
    end

    self.container:SetVisible(true);
end

function TextDisplay:UnloadCharacters()
    for i, v in ipairs(self.characters) do
        v:SetVisible(false);
        v:SetParent(nil);
    end
    self.characters = {};
    collectgarbage();
end

function TextDisplay:Unload()
    self:UnloadCharacters();
end