Menu = class(Turbine.UI.Window)
function Menu:Constructor( x, y )
	Turbine.UI.Window.Constructor( self );

	self:SetSize(450, 624);

	self:SetPosition(x,y);
	self:SetVisible(true);
	self.dragging = false;

	self.screenWidth, self.screenHeight = Turbine.UI.Display:GetSize();
	self.screenWidth = self.screenWidth - self:GetWidth();
	self.screenHeight = self.screenHeight - self:GetHeight();

	self:CreateWindow(450, 624);

	self:CreateContent();
	self:SetData();
end

function Menu:ToggleVisible()
	self:SetVisible(not self:IsVisible());
end

function Menu:CreateWindow(width, height)
	self.title = Turbine.UI.Control();
	self.title:SetParent(self);
	self.title:SetBackground("ExoPlugins/Acumen/Resources/UI/Title.tga");
	self.title:SetSize(116,32);
	self.title:SetStretchMode(1);
	self.title:SetPosition((width/2)-58,0);
	self.title:SetZOrder(101);

	self.title.MouseDown = function(sender, args)
		self.startX = args.X;
		self.startY = args.Y;
		self.dragging = true;
	end

	self.title.MouseUp = function(sender, args)
		self.dragging = false;
	end

	self.title.MouseMove = function(sender, args)
		if self.dragging then
			local left, top = self:GetPosition();
			local x = left + (args.X - self.startX);
			local y = top + (args.Y - self.startY);
			self:SetPosition(Clamp(x, 0, self.screenWidth), Clamp(y, 0, self.screenHeight));
		end
	end

	-- The display text for the title.
	self.titleText = Turbine.UI.Label();
	self.titleText:SetForeColor( Turbine.UI.Color(1,0.84,0.46) );
	self.titleText:SetOutlineColor( Turbine.UI.Color( 1, 0, 0, 0 ) );
	self.titleText:SetFontStyle( Turbine.UI.FontStyle.Outline );
	self.titleText:SetFont( Turbine.UI.Lotro.Font.BookAntiquaBold22 );
	self.titleText:SetTextAlignment( Turbine.UI.ContentAlignment.MiddleCenter );
	self.titleText:SetParent(self.title)
	self.titleText:SetSize(76, 19);
    self.titleText:SetPosition(20, 5)
	self.titleText:SetZOrder( 110 );
	self.titleText:SetStretchMode(1);
	self.titleText:SetMouseVisible(false);
	self.titleText:SetText("Acumen");

	self.exit = Turbine.UI.Control();
	self.exit:SetParent(self);
	self.exit:SetBackground("ExoPlugins/Acumen/Resources/UI/xButton.tga");
	self.exit:SetSize(64,64);
	self.exit:SetStretchMode(1);
	self.exit:SetSize(32,32);
	self.exit:SetPosition(width-36,1);
	self.exit:SetZOrder(101);

	self.exit.MouseEnter = function(sender, args)
		self.exit:SetBackground("ExoPlugins/Acumen/Resources/UI/xButtonHover.tga");
	end

	self.exit.MouseLeave = function(sender, args)
		self.exit:SetBackground("ExoPlugins/Acumen/Resources/UI/xButton.tga");
	end

	self.exit.MouseClick = function(sender, args)
		self:ToggleVisible();
	end

	local frameOffset = 13;
	local frameHeight = height-frameOffset;
	local frameWidth = width;


	self.border1 = Turbine.UI.Control();
    self.border1:SetParent( self );
	self.border1:SetBackground("ExoPlugins/Acumen/Resources/UI/Border1.tga")
	self.border1:SetSize(16,16);
	self.border1:SetStretchMode(1);
	self.border1:SetSize(8,8);
	self.border1:SetPosition(0,frameOffset);

	self.border2 = Turbine.UI.Control();
    self.border2:SetParent( self );
	self.border2:SetBackground("ExoPlugins/Acumen/Resources/UI/Border2.tga")
	self.border2:SetSize(frameWidth,16);
	self.border2:SetStretchMode(1);
	self.border2:SetSize(frameWidth-16,8);
	self.border2:SetPosition(8,frameOffset);

	self.border3 = Turbine.UI.Control();
    self.border3:SetParent( self );
	self.border3:SetBackground("ExoPlugins/Acumen/Resources/UI/Border3.tga")
	self.border3:SetSize(16,16);
	self.border3:SetStretchMode(1);
	self.border3:SetSize(8,8);
	self.border3:SetPosition(frameWidth-8,frameOffset);

	self.border4 = Turbine.UI.Control();
    self.border4:SetParent( self );
	self.border4:SetBackground("ExoPlugins/Acumen/Resources/UI/Border4.tga")
	self.border4:SetSize(16,frameHeight);
	self.border4:SetStretchMode(1);
	self.border4:SetSize(8,frameHeight-16);
	self.border4:SetPosition(frameWidth-8,frameOffset+8);

	self.border5 = Turbine.UI.Control();
    self.border5:SetParent( self );
	self.border5:SetBackground("ExoPlugins/Acumen/Resources/UI/Border5.tga")
	self.border5:SetSize(16,16);
	self.border5:SetStretchMode(1);
	self.border5:SetSize(8,8);
	self.border5:SetPosition(frameWidth-8,height-8);

	self.border6 = Turbine.UI.Control();
    self.border6:SetParent( self );
	self.border6:SetBackground("ExoPlugins/Acumen/Resources/UI/Border6.tga")
	self.border6:SetSize(frameWidth,16);
	self.border6:SetStretchMode(1);
	self.border6:SetSize(frameWidth-16,8);
	self.border6:SetPosition(8,height-8);

	self.border7 = Turbine.UI.Control();
    self.border7:SetParent( self );
	self.border7:SetBackground("ExoPlugins/Acumen/Resources/UI/Border7.tga")
	self.border7:SetSize(16,16);
	self.border7:SetStretchMode(1);
	self.border7:SetSize(8,8);
	self.border7:SetPosition(0,height-8);

	self.border8 = Turbine.UI.Control();
    self.border8:SetParent( self );
	self.border8:SetBackground("ExoPlugins/Acumen/Resources/UI/Border8.tga")
	self.border8:SetSize(16,frameHeight);
	self.border8:SetStretchMode(1);
	self.border8:SetSize(8,frameHeight-16);
	self.border8:SetPosition(0,frameOffset+8);

	self.content = Turbine.UI.Control();
	self.content:SetParent(self);
	self.content:SetBackColor(Turbine.UI.Color( 0.9, 0, 0, 0 ));
	self.content:SetSize(frameWidth-16, frameHeight-16);
	self.content:SetPosition(8,frameOffset+8);
end

function Menu:CreateContent()
	local contentHeight = 455;

	local settingsBorder = Border();
	settingsBorder:SetParent(self.content);
	settingsBorder:SetSize(416, 470);
	settingsBorder:SetPosition(10,34);

	local buttonsBorder = Border();
	buttonsBorder:SetParent(self.content);
	buttonsBorder:SetSize(416, 72);
	buttonsBorder:SetPosition(10,514);


	self.vitalSettingsContainer = Turbine.UI.Control();
	self.vitalSettingsContainer:SetSize(408, contentHeight);
	self.vitalSettingsContainer:SetPosition(15, 42);
	self.vitalSettingsContainer:SetVisible(true);
	self.vitalSettingsContainer:SetParent(self.content);

	self.effectSettingsContainer = Turbine.UI.Control();
	self.effectSettingsContainer:SetSize(408, contentHeight);
	self.effectSettingsContainer:SetPosition(15, 42);
	self.effectSettingsContainer:SetVisible(false);
	self.effectSettingsContainer:SetParent(self.content);

	self.vitalsButton = Button("Vitals", 150);
	self.vitalsButton:SetParent(self.content);
	self.vitalsButton:SetPosition(51, 10);

	self.vitalsButton.MouseClick = function(sender, args)
		self.vitalSettingsContainer:SetVisible(true);
		self.effectSettingsContainer:SetVisible(false);
	end

	self.effectsButton = Button("Effects", 150);
	self.effectsButton:SetParent(self.content);
	self.effectsButton:SetPosition(237, 10);

	self.effectsButton.MouseClick = function(sender, args)
		self.vitalSettingsContainer:SetVisible(false);
		self.effectSettingsContainer:SetVisible(true);
	end

	self.settings = Turbine.UI.TreeView();
	self.settings:SetParent(self.vitalSettingsContainer);
	self.settings:SetSize(398, contentHeight);
	self.settings:SetPosition(0, 0);
	self.settings:SetIndentationWidth( 0 );

	self.settingsScrollBar = ScrollBar();
	self.settingsScrollBar:SetOrientation( Turbine.UI.Orientation.Vertical );
	self.settingsScrollBar:SetParent( self.vitalSettingsContainer );
	self.settingsScrollBar:SetPosition( 397, 0 );
	self.settingsScrollBar:SetSize( 10, contentHeight );

	self.settings:SetVerticalScrollBar( self.settingsScrollBar );

	self.buffSettings = Turbine.UI.TreeView();
	self.buffSettings:SetParent(self.effectSettingsContainer);
	self.buffSettings:SetSize(398, contentHeight);
	self.buffSettings:SetPosition(0, 0);
	self.buffSettings:SetIndentationWidth( 0 );

	self.buffSettingsScrollBar = ScrollBar();
	self.buffSettingsScrollBar:SetOrientation( Turbine.UI.Orientation.Vertical );
	self.buffSettingsScrollBar:SetParent( self.effectSettingsContainer );
	self.buffSettingsScrollBar:SetPosition( 397, 0 );
	self.buffSettingsScrollBar:SetSize( 10, contentHeight );

	self.buffSettings:SetVerticalScrollBar( self.buffSettingsScrollBar );

	-- self:LoadBuffSettings(self.buffSettings);

	------------------------------------------------------------

	self.moraleNode = HeaderNode("Morale");
	self.moraleSettings = SettingsNode();
	self.moraleNode:GetChildNodes():Add(self.moraleSettings);

	local subheading = Subheading("Position");
	self.moraleSettings:AddContent(subheading);

	local double = DoubleBox();
	self.moralePositionX = Slider();
	self.moralePositionX:SetAlignment("vertical");
	self.moralePositionX:SetKey("X Offset");
	self.moralePositionX:SetSize(173, 50);
	self.moralePositionX:SetRange(0, 100);
	double:AddContent(self.moralePositionX);

	self.moralePositionY = Slider();
	self.moralePositionY:SetAlignment("vertical");
	self.moralePositionY:SetKey("Y Offset");
	self.moralePositionY:SetSize(173, 50);
	self.moralePositionY:SetRange(0, 100);
	double:AddContent(self.moralePositionY);

	self.moraleSettings:AddContent(double);

	local subheading = Subheading("Bar");
	self.moraleSettings:AddContent(subheading);

	self.playerMoraleColour = ExpandingDropDownSetting("Morale Colour:");
	local list = {"Default","Class Colour","Custom"};
	self.playerMoraleColour:AddList(list);

	self.customPlayerMoraleColour = ColourSetting();
	self.playerMoraleColour:AddContent("Custom", self.customPlayerMoraleColour);

	self.moraleSettings:AddContent(self.playerMoraleColour);

	self.playerBubbleColour = ExpandingDropDownSetting("Bubble Colour:");
	local list = {"Default","Custom"};
	self.playerBubbleColour:AddList(list);

	self.customPlayerBubbleColour = ColourSetting();
	self.playerBubbleColour:AddContent("Custom", self.customPlayerBubbleColour);

	self.moraleSettings:AddContent(self.playerBubbleColour);

	self.playerDreadColour = ExpandingDropDownSetting("Dread Colour:");
	local list = {"Default","Custom"};
	self.playerDreadColour:AddList(list);

	self.customPlayerDreadColour = ColourSetting();
	self.playerDreadColour:AddContent("Custom", self.customPlayerDreadColour);

	self.moraleSettings:AddContent(self.playerDreadColour);

	local double = DoubleBox();
	self.moraleWidth = Slider();
	self.moraleWidth:SetAlignment("vertical");
	self.moraleWidth:SetKey("Width");
	self.moraleWidth:SetSize(173, 50);
	self.moraleWidth:SetRange(0, 500);
	double:AddContent(self.moraleWidth);

	self.moraleHeight = Slider();
	self.moraleHeight:SetAlignment("vertical");
	self.moraleHeight:SetKey("Height");
	self.moraleHeight:SetSize(173, 50);
	self.moraleHeight:SetRange(0, 500);
	double:AddContent(self.moraleHeight);

	self.moraleSettings:AddContent(double);

	local subheading = Subheading("Text");
	self.moraleSettings:AddContent(subheading);

	local double = DoubleBox();
	self.moraleTextAnchor = DropDownSetting("Morale Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.moraleTextAnchor:AddList(list);
	double:AddContent(self.moraleTextAnchor);

	self.moraleTextScale = Slider();
	self.moraleTextScale:SetAlignment("vertical");
	self.moraleTextScale:SetKey("Text Scale");
	self.moraleTextScale:SetSize(173, 50);
	self.moraleTextScale:SetRange(0, 100);
	double:AddContent(self.moraleTextScale);

	self.moraleSettings:AddContent(double);

	local double = DoubleBox();
	self.moraleTextXOffset = Slider();
	self.moraleTextXOffset:SetAlignment("vertical");
	self.moraleTextXOffset:SetKey("X Offset");
	self.moraleTextXOffset:SetSize(173, 50);
	self.moraleTextXOffset:SetRange(-50, 50);
	double:AddContent(self.moraleTextXOffset);

	self.moraleTextYOffset = Slider();
	self.moraleTextYOffset:SetAlignment("vertical");
	self.moraleTextYOffset:SetKey("Y Offset");
	self.moraleTextYOffset:SetSize(173, 50);
	self.moraleTextYOffset:SetRange(-50, 50);
	double:AddContent(self.moraleTextYOffset);

	self.moraleSettings:AddContent(double);

	self.moraleTextColor = ColourSetting("Text Colour: ");
	self.moraleTextColor:SetColor(Turbine.UI.Color(1, 1, 1))
	self.moraleSettings:AddContent(self.moraleTextColor);

	self.moraleTextFormat = TextSetting("Morale Text Format:", 150);
	self.moraleTextFormat:CreateTooltip("Set the format in which the morale text \nwill display.\n\n%p will display as the current percentage\n%v will display the current value");

	self.moraleSettings:AddContent(self.moraleTextFormat);

	local subheading = Subheading("Bubble Text");
	self.moraleSettings:AddContent(subheading);

	self.bubbleTextEnabled = ExpandingCheckBoxSetting("Enabled:");

	local double = DoubleBox();
	self.bubbleTextAnchor = DropDownSetting("Bubble Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.bubbleTextAnchor:AddList(list);
	double:AddContent(self.bubbleTextAnchor);

	self.bubbleTextScale = Slider();
	self.bubbleTextScale:SetAlignment("vertical");
	self.bubbleTextScale:SetKey("Text Scale");
	self.bubbleTextScale:SetSize(173, 50);
	self.bubbleTextScale:SetRange(0, 100);
	double:AddContent(self.bubbleTextScale);

	self.bubbleTextEnabled:AddContent(double);

	local double = DoubleBox();
	self.bubbleTextXOffset = Slider();
	self.bubbleTextXOffset:SetAlignment("vertical");
	self.bubbleTextXOffset:SetKey("X Offset");
	self.bubbleTextXOffset:SetSize(173, 50);
	self.bubbleTextXOffset:SetRange(-50, 50);
	double:AddContent(self.bubbleTextXOffset);

	self.bubbleTextYOffset = Slider();
	self.bubbleTextYOffset:SetAlignment("vertical");
	self.bubbleTextYOffset:SetKey("Y Offset");
	self.bubbleTextYOffset:SetSize(173, 50);
	self.bubbleTextYOffset:SetRange(-50, 50);
	double:AddContent(self.bubbleTextYOffset);

	self.bubbleTextEnabled:AddContent(double);

	self.bubbleTextColor = ColourSetting("Text Colour: ");
	self.bubbleTextColor:SetColor(Turbine.UI.Color(1, 1, 1))
	self.bubbleTextEnabled:AddContent(self.bubbleTextColor);

	self.moraleSettings:AddContent(self.bubbleTextEnabled);

	------------------------------------------

	self.powerNode = HeaderNode("Power");
	self.powerSettings = SettingsNode();
	self.powerNode:GetChildNodes():Add(self.powerSettings);

	local subheading = Subheading("Position");
	self.powerSettings:AddContent(subheading);

	local double = DoubleBox();
	self.powerPositionX = Slider();
	self.powerPositionX:SetAlignment("vertical");
	self.powerPositionX:SetKey("X Offset");
	self.powerPositionX:SetSize(173, 50);
	self.powerPositionX:SetRange(0, 100);
	double:AddContent(self.powerPositionX);

	self.powerPositionY = Slider();
	self.powerPositionY:SetAlignment("vertical");
	self.powerPositionY:SetKey("Y Offset");
	self.powerPositionY:SetSize(173, 50);
	self.powerPositionY:SetRange(0, 100);
	double:AddContent(self.powerPositionY);

	self.powerSettings:AddContent(double);

	local subheading = Subheading("Bar");
	self.powerSettings:AddContent(subheading);

	self.playerPowerColour = ExpandingDropDownSetting("Power Colour:");
	local list = {"Default","Custom"};
	self.playerPowerColour:AddList(list);

	self.customPlayerPowerColour = ColourSetting();
	self.playerPowerColour:AddContent("Custom", self.customPlayerPowerColour);

	self.powerSettings:AddContent(self.playerPowerColour);

	local double = DoubleBox();
	self.powerWidth = Slider();
	self.powerWidth:SetAlignment("vertical");
	self.powerWidth:SetKey("Width");
	self.powerWidth:SetSize(173, 50);
	self.powerWidth:SetRange(0, 500);
	double:AddContent(self.powerWidth);

	self.powerHeight = Slider();
	self.powerHeight:SetAlignment("vertical");
	self.powerHeight:SetKey("Height");
	self.powerHeight:SetSize(173, 50);
	self.powerHeight:SetRange(0, 500);
	double:AddContent(self.powerHeight);

	self.powerSettings:AddContent(double);

	--------------------------------------------------------

	self.textNode = HeaderNode("Name");
	self.textSettings = SettingsNode();
	self.textNode:GetChildNodes():Add(self.textSettings);

	local subheading = Subheading("Text");
	self.textSettings:AddContent(subheading);

	self.nameTextFormat = TextSetting("Name Text Format:", 172);
	self.nameTextFormat:CreateTooltip("Set the format in which the name text \nwill display.\n\n%n will display as the current characters name\n%l will display the current characters level");
	self.textSettings:AddContent(self.nameTextFormat);

	local double = DoubleBox();
	self.nameTextAnchor = DropDownSetting("Name Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.nameTextAnchor:AddList(list);
	double:AddContent(self.nameTextAnchor);

	self.nameTextScale = Slider();
	self.nameTextScale:SetAlignment("vertical");
	self.nameTextScale:SetKey("Text Scale");
	self.nameTextScale:SetSize(173, 50);
	self.nameTextScale:SetRange(0, 100);
	double:AddContent(self.nameTextScale);

	self.textSettings:AddContent(double);

	local double = DoubleBox();
	self.nameTextXOffset = Slider();
	self.nameTextXOffset:SetAlignment("vertical");
	self.nameTextXOffset:SetKey("X Offset");
	self.nameTextXOffset:SetSize(173, 50);
	self.nameTextXOffset:SetRange(-50, 50);
	double:AddContent(self.nameTextXOffset);

	self.nameTextYOffset = Slider();
	self.nameTextYOffset:SetAlignment("vertical");
	self.nameTextYOffset:SetKey("Y Offset");
	self.nameTextYOffset:SetSize(173, 50);
	self.nameTextYOffset:SetRange(-50, 50);
	double:AddContent(self.nameTextYOffset);

	self.textSettings:AddContent(double);

	self.nameTextColor = ColourSetting("Text Colour: ");
	self.nameTextColor:SetColor(Turbine.UI.Color(1, 1, 1))

	self.textSettings:AddContent(self.nameTextColor);

	-------------------------------------------------------------

	self.effectsNode = HeaderNode("Effects");
	self.effectsSettings = SettingsNode();
	self.effectsNode:GetChildNodes():Add(self.effectsSettings);

	local subheading = Subheading("Display");
	self.effectsSettings:AddContent(subheading);

	local double = DoubleBox();
	self.effectsBasicEnabled = CheckBoxSetting("Enabled: ");
	double:AddContent(self.effectsBasicEnabled);
	self.effectsSettings:AddContent(double);

	local subheading = Subheading("Size");
	self.effectsSettings:AddContent(subheading);

	local double = DoubleBox();
	self.effectsWidth = Slider();
	self.effectsWidth:SetAlignment("vertical");
	self.effectsWidth:SetKey("Width");
	self.effectsWidth:SetSize(173, 50);
	self.effectsWidth:SetRange(0, 64);
	double:AddContent(self.effectsWidth);

	self.effectsHeight = Slider();
	self.effectsHeight:SetAlignment("vertical");
	self.effectsHeight:SetKey("Height");
	self.effectsHeight:SetSize(173, 50);
	self.effectsHeight:SetRange(0, 64);
	double:AddContent(self.effectsHeight);

	self.effectsSettings:AddContent(double);

	self.effectsZoom = Slider();
	self.effectsZoom:SetAlignment("vertical");
	self.effectsZoom:SetKey("Zoom (%)");
	self.effectsZoom:SetRange(0,100);
	self.effectsZoom:SetSize(366,50);

	self.effectsSettings:AddContent(self.effectsZoom);

	local subheading = Subheading("Stack");
	self.effectsSettings:AddContent(subheading);

	local double = DoubleBox();
	self.stackTextAnchor = DropDownSetting("Stack Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.stackTextAnchor:AddList(list);
	double:AddContent(self.stackTextAnchor);

	self.stackTextScale = Slider();
	self.stackTextScale:SetAlignment("vertical");
	self.stackTextScale:SetKey("Text Scale");
	self.stackTextScale:SetSize(173, 50);
	self.stackTextScale:SetRange(0, 100);
	double:AddContent(self.stackTextScale);

	self.effectsSettings:AddContent(double);

	local double = DoubleBox();
	self.stackTextXOffset = Slider();
	self.stackTextXOffset:SetAlignment("vertical");
	self.stackTextXOffset:SetKey("X Offset");
	self.stackTextXOffset:SetSize(173, 50);
	self.stackTextXOffset:SetRange(-50, 50);
	double:AddContent(self.stackTextXOffset);

	self.stackTextYOffset = Slider();
	self.stackTextYOffset:SetAlignment("vertical");
	self.stackTextYOffset:SetKey("Y Offset");
	self.stackTextYOffset:SetSize(173, 50);
	self.stackTextYOffset:SetRange(-50, 50);
	double:AddContent(self.stackTextYOffset);

	self.effectsSettings:AddContent(double);

	self.stackTextColor = ColourSetting("Text Colour: ");
	self.stackTextColor:SetColor(Turbine.UI.Color(1, 1, 1))

	self.effectsSettings:AddContent(self.stackTextColor);

	local subheading = Subheading("Cooldown");
	self.effectsSettings:AddContent(subheading);

	local double = DoubleBox();
	self.durationTextAnchor = DropDownSetting("CD Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.durationTextAnchor:AddList(list);
	double:AddContent(self.durationTextAnchor);

	self.durationTextScale = Slider();
	self.durationTextScale:SetAlignment("vertical");
	self.durationTextScale:SetKey("Text Scale");
	self.durationTextScale:SetSize(173, 50);
	self.durationTextScale:SetRange(0, 100);
	double:AddContent(self.durationTextScale);

	self.effectsSettings:AddContent(double);

	local double = DoubleBox();
	self.durationTextXOffset = Slider();
	self.durationTextXOffset:SetAlignment("vertical");
	self.durationTextXOffset:SetKey("X Offset");
	self.durationTextXOffset:SetSize(173, 50);
	self.durationTextXOffset:SetRange(-50, 50);
	double:AddContent(self.durationTextXOffset);

	self.durationTextYOffset = Slider();
	self.durationTextYOffset:SetAlignment("vertical");
	self.durationTextYOffset:SetKey("Y Offset");
	self.durationTextYOffset:SetSize(173, 50);
	self.durationTextYOffset:SetRange(-50, 50);
	double:AddContent(self.durationTextYOffset);

	self.effectsSettings:AddContent(double);

	self.durationTextColor = ColourSetting("Text Colour: ");
	self.durationTextColor:SetColor(Turbine.UI.Color(1, 1, 1))

	self.effectsSettings:AddContent(self.durationTextColor);

	------------------------------

	self.targetNode = HeaderNode("Target");
	self.targetSettings = SettingsNode();
	self.targetNode:GetChildNodes():Add(self.targetSettings);

	self.targetEnabled = ExpandingCheckBoxSetting("Enabled:");

	local subheading = Subheading("Vitals");
	self.targetEnabled:AddContent(subheading);

	self.targetMoraleColour = ExpandingDropDownSetting("Morale Colour:");
	local list = {"Default","Custom"};
	self.targetMoraleColour:AddList(list);

	self.customTargetMoraleColour = ColourSetting();
	self.targetMoraleColour:AddContent("Custom", self.customTargetMoraleColour);

	self.targetEnabled:AddContent(self.targetMoraleColour);

	self.targetTextFormat = TextSetting("Morale Text Format:", 172);
	self.targetTextFormat:CreateTooltip("Set the format in which the morale text \nwill display.\n\n%p will display as the current percentage\n%v will display the current value");
	self.targetEnabled:AddContent(self.targetTextFormat);

	self.targetNameFormat = TextSetting("Name Text Format:", 172);
	self.targetNameFormat:CreateTooltip("Set the format in which the name text \nwill display.\n\n%n will display as the current targets name\n%l will display the current characters level");
	self.targetEnabled:AddContent(self.targetNameFormat);

	local subheading = Subheading("TTK");
	self.targetEnabled:AddContent(subheading);

	self.ttkEnabled = ExpandingCheckBoxSetting("Enabled:");
	self.ttkEnabled:CreateTooltip("Enables the time-to-kill estimate which roughly\ncalculates how long it will take to kill the\ncurrent target.");

	local double = DoubleBox();
	self.ttkTextAnchor = DropDownSetting("TTK Text Anchor:");
	local list = {"Top Left","Top Center", "Top Right", "Middle Left", "Middle Center", "Middle Right", "Bottom Left", "Bottom Center", "Bottom Right"};
	self.ttkTextAnchor:AddList(list);
	double:AddContent(self.ttkTextAnchor);

	self.ttkTextScale = Slider();
	self.ttkTextScale:SetAlignment("vertical");
	self.ttkTextScale:SetKey("Text Scale");
	self.ttkTextScale:SetSize(173, 50);
	self.ttkTextScale:SetRange(0, 100);
	double:AddContent(self.ttkTextScale);

	self.ttkEnabled:AddContent(double);

	local double = DoubleBox();
	self.ttkTextXOffset = Slider();
	self.ttkTextXOffset:SetAlignment("vertical");
	self.ttkTextXOffset:SetKey("X Offset");
	self.ttkTextXOffset:SetSize(173, 50);
	self.ttkTextXOffset:SetRange(-50, 50);
	double:AddContent(self.ttkTextXOffset);

	self.ttkTextYOffset = Slider();
	self.ttkTextYOffset:SetAlignment("vertical");
	self.ttkTextYOffset:SetKey("Y Offset");
	self.ttkTextYOffset:SetSize(173, 50);
	self.ttkTextYOffset:SetRange(-50, 50);
	double:AddContent(self.ttkTextYOffset);

	self.ttkEnabled:AddContent(double);

	self.ttkTextColor = ColourSetting("Text Colour: ");
	self.ttkTextColor:SetColor(Turbine.UI.Color(1, 1, 1))
	self.ttkEnabled:AddContent(self.ttkTextColor);

	self.targetEnabled:AddContent(self.ttkEnabled);

	self.targetSettings:AddContent(self.targetEnabled);

	self.settings:GetNodes():Add(self.moraleNode);
	self.settings:GetNodes():Add(self.powerNode);
	self.settings:GetNodes():Add(self.textNode);
	self.settings:GetNodes():Add(self.effectsNode);
	self.settings:GetNodes():Add(self.targetNode);
	self.settings:ExpandAll();

	------------------------------------------------------------

	self.buffsWhitelist = HeaderNode("Buffs Whitelist");
	self.buffsTree = Turbine.UI.TreeNode();
	self.buffsTree:SetSize(400,3);
	self.buffsWhitelist:GetChildNodes():Add(self.buffsTree);
	self.buffSettings:GetNodes():Add(self.buffsWhitelist);
	self.addBuffs = TreeButton();
	self.buffsWhitelist:GetChildNodes():Add(self.addBuffs);

	self.addBuffs.button.MouseClick = function(sender, args)
		local BuffNode = BuffNode("Insert Buff Name");
		self.buffsTree:GetChildNodes():Add(BuffNode);
		self.buffsTree:CollapseAll();
		self.buffsTree:ExpandAll();
	end

	self.debuffsWhitelist = HeaderNode("Debuffs Blacklist");
	self.debuffsTree = Turbine.UI.TreeNode();
	self.debuffsTree:SetSize(400,3);
	self.debuffsWhitelist:GetChildNodes():Add(self.debuffsTree);
	self.buffSettings:GetNodes():Add(self.debuffsWhitelist);
	self.addDebuffs = TreeButton();
	self.debuffsWhitelist:GetChildNodes():Add(self.addDebuffs);

	self.addDebuffs.button.MouseClick = function(sender, args)
		local BuffNode = BuffNode("Insert Debuff Name");
		self.debuffsTree:GetChildNodes():Add(BuffNode);
		self.debuffsTree:CollapseAll();
		self.debuffsTree:ExpandAll();
	end

	self.importExport = HeaderNode("Import/Export");
	self.importExportTree = Turbine.UI.TreeNode();
	self.importExportTree:SetSize(400,3);
	self.importExport:GetChildNodes():Add(self.importExportTree);
	self.buffSettings:GetNodes():Add(self.importExport);
	self.import = TreeGrid("Import Buffs", "Import Debuffs", "Export Buffs", "Export Debuffs");
	self.importExport:GetChildNodes():Add(self.import);

	self.IOWindow = DetailedWindow();
	self.IOWindow:SetVisible(false);

	self.import.button1.MouseClick = function(sender, args)
		self.IOWindow:Open(1);
	end

	self.import.button2.MouseClick = function(sender, args)
		self.IOWindow:Open(2);
	end

	self.import.button3.MouseClick = function(sender, args)
		self.IOWindow:Open(3);
	end

	self.import.button4.MouseClick = function(sender, args)
		self.IOWindow:Open(4);
	end

	self:LoadEffectSettings();

	------------------------------------------------------------

	self.revertButton = Button("Revert Changes", 150);
	self.revertButton:SetParent(self.content);
	self.revertButton:SetPosition(51, 539);

	self.revertButton.MouseClick = function(sender, args)
		self:SetData();
	end

	self.saveButton = Button("Save Changes", 150);
	self.saveButton:SetParent(self.content);
	self.saveButton:SetPosition(237, 539);

	self.saveButton.MouseClick = function(sender, args)
		_G.Settings = self:GetData();
		ReloadPlugin();
	end
end

function Menu:LoadEffectSettings()
	self.buffsTree:GetChildNodes():Clear();
	self.debuffsTree:GetChildNodes():Clear();
	local buffs = {};
	for key in pairs(Settings["Effects"]["Buffs"]) do
		table.insert(buffs, key);
	end
	table.sort(buffs);
	for key, value in pairs(buffs) do
		local BuffNode = BuffNode(value);
		self.buffsTree:GetChildNodes():Add(BuffNode);
	end

	local debuffs = {};
	for key in pairs(Settings["Effects"]["Debuffs"]) do
		table.insert(debuffs, key);
	end
	table.sort(debuffs);
	for key, value in pairs(debuffs) do
		local BuffNode = BuffNode(value);
		self.debuffsTree:GetChildNodes():Add(BuffNode);
	end

	self.buffSettings:ExpandAll();
end

function Menu:GetEffectSettings()
	local nodeList = self.buffsTree:GetChildNodes();
	local buffs = {};
	for i=1, nodeList:GetCount(), 1 do
		buffs[nodeList:Get(i):GetName()] = true;
	end

	local nodeList = self.debuffsTree:GetChildNodes();
	local debuffs = {};
	for i=1, nodeList:GetCount(), 1 do
		debuffs[nodeList:Get(i):GetName()] = true;
	end

	local table = {
		Buffs = buffs,
		Debuffs = debuffs,
		Basic = {
			Position = _G.Settings.Effects.Basic.Position;
			Enabled = self.effectsBasicEnabled:GetValue();
		}
	}
	return table;
end

function Menu:GetData()
	local data = {
		Player = {
			Position = Settings.Player.Position,
			Vitals = {
				Morale = {
					Position = {
						X = self.moralePositionX:GetValue(),
						Y = self.moralePositionY:GetValue(),
					},
					Display = self.playerMoraleColour:GetSelected(),
					Color = ColorToTable(self.customPlayerMoraleColour:GetColor()),
					BubbleDisplay = self.playerBubbleColour:GetSelected(),
					BubbleColor = ColorToTable(self.customPlayerBubbleColour:GetColor()),
					DreadDisplay = self.playerDreadColour:GetSelected(),
					DreadColor = ColorToTable(self.customPlayerDreadColour:GetColor()),
					Size = {
						X = self.moraleWidth:GetValue(),
						Y = self.moraleHeight:GetValue(),
					},
					Text = {
						Anchor = StringToAlignment(self.moraleTextAnchor:GetSelected()),
						Format = self.moraleTextFormat:GetText(),
						Offset = {
							X = self.moraleTextXOffset:GetValue(),
							Y = self.moraleTextYOffset:GetValue(),
						},
						Color = ColorToTable(self.moraleTextColor:GetColor()),
						Scale = self.moraleTextScale:GetValue()/100,
					},
					BubbleText = {
						Enabled = self.bubbleTextEnabled:GetData(),
						Anchor = StringToAlignment(self.bubbleTextAnchor:GetSelected()),
						Offset = {
							X = self.bubbleTextXOffset:GetValue(),
							Y = self.bubbleTextYOffset:GetValue(),
						},
						Color = ColorToTable(self.bubbleTextColor:GetColor()),
						Scale = self.bubbleTextScale:GetValue()/100,
					}
				},
				Power = {
					Position = {
						X = self.powerPositionX:GetValue(),
						Y = self.powerPositionY:GetValue(),
					},
					Display = self.playerPowerColour:GetSelected(),
					Color = ColorToTable(self.customPlayerPowerColour:GetColor()),
					Size = {
						X = self.powerWidth:GetValue(),
						Y = self.powerHeight:GetValue(),
					},
				},
				Text = {
					Anchor = StringToAlignment(self.nameTextAnchor:GetSelected()),
					Offset = {
						X = self.nameTextXOffset:GetValue(),
						Y = self.nameTextYOffset:GetValue(),
					},
					Format = self.nameTextFormat:GetText(),
					Color = ColorToTable(self.nameTextColor:GetColor()),
					Scale = self.nameTextScale:GetValue()/100,
				}
			},
			Effects = {
				Size = {
					X = self.effectsWidth:GetValue(),
					Y = self.effectsHeight:GetValue(),
					Zoom = self.effectsZoom:GetValue()/100,
				},
				Stack = {
					Anchor = StringToAlignment(self.stackTextAnchor:GetSelected()),
					Offset = {
						X = self.stackTextXOffset:GetValue(),
						Y = self.stackTextYOffset:GetValue(),
					},
					Scale = self.stackTextScale:GetValue()/100,
					Color = ColorToTable(self.stackTextColor:GetColor()),
				},
				Duration = {
					Anchor = StringToAlignment(self.durationTextAnchor:GetSelected()),
					Offset = {
						X = self.durationTextXOffset:GetValue(),
						Y = self.durationTextYOffset:GetValue(),
					},
					Scale = self.durationTextScale:GetValue()/100,
					Color = ColorToTable(self.durationTextColor:GetColor()),
				},
			}
		},
		Target = {
			Enabled = self.targetEnabled:GetData(),
			Position = Settings.Target.Position,
			Vitals = {
				Text = {
					Format = self.targetNameFormat:GetText(),
				},
				Morale = {
					Display = self.targetMoraleColour:GetSelected(),
					Color = ColorToTable(self.customTargetMoraleColour:GetColor()),
					Text = {
						Format = self.targetTextFormat:GetText(),
					},
				},
				TimeToKill = {
					Enabled = self.ttkEnabled:GetData(),
					Anchor = StringToAlignment(self.ttkTextAnchor:GetSelected()),
					Offset = {
						X = self.ttkTextXOffset:GetValue(),
						Y = self.ttkTextYOffset:GetValue(),
					},
					Scale = self.ttkTextScale:GetValue()/100,
					Color = ColorToTable(self.ttkTextColor:GetColor()),
				},
			},
		},
		Logo = Settings.Logo,
		Effects = self:GetEffectSettings(),
	}
	return data;
end

function Menu:SetData()
	self.moralePositionX:SetValue(Settings.Player.Vitals.Morale.Position.X);
	self.moralePositionY:SetValue(Settings.Player.Vitals.Morale.Position.Y);

	self.playerMoraleColour:SetSelected(Settings.Player.Vitals.Morale.Display);
	self.customPlayerMoraleColour:SetColor(TableToColor(Settings.Player.Vitals.Morale.Color));
	self.playerBubbleColour:SetSelected(Settings.Player.Vitals.Morale.BubbleDisplay);
	self.customPlayerBubbleColour:SetColor(TableToColor(Settings.Player.Vitals.Morale.BubbleColor));
	self.playerDreadColour:SetSelected(Settings.Player.Vitals.Morale.DreadDisplay);
	self.customPlayerDreadColour:SetColor(TableToColor(Settings.Player.Vitals.Morale.DreadColor));
	self.moraleWidth:SetValue(Settings.Player.Vitals.Morale.Size.X);
	self.moraleHeight:SetValue(Settings.Player.Vitals.Morale.Size.Y);

	self.moraleTextAnchor:SetSelected(AlignmentToString(Settings.Player.Vitals.Morale.Text.Anchor));
	self.moraleTextFormat:SetText(Settings.Player.Vitals.Morale.Text.Format);
	self.moraleTextXOffset:SetValue(Settings.Player.Vitals.Morale.Text.Offset.X);
	self.moraleTextYOffset:SetValue(Settings.Player.Vitals.Morale.Text.Offset.Y);
	self.moraleTextColor:SetColor(TableToColor(Settings.Player.Vitals.Morale.Text.Color));
	self.moraleTextScale:SetValue(Settings.Player.Vitals.Morale.Text.Scale*100);

	self.bubbleTextEnabled:SetData(Settings.Player.Vitals.Morale.BubbleText.Enabled);
	self.bubbleTextAnchor:SetSelected(AlignmentToString(Settings.Player.Vitals.Morale.BubbleText.Anchor));
	self.bubbleTextXOffset:SetValue(Settings.Player.Vitals.Morale.BubbleText.Offset.X);
	self.bubbleTextYOffset:SetValue(Settings.Player.Vitals.Morale.BubbleText.Offset.Y);
	self.bubbleTextColor:SetColor(TableToColor(Settings.Player.Vitals.Morale.BubbleText.Color));
	self.bubbleTextScale:SetValue(Settings.Player.Vitals.Morale.BubbleText.Scale*100);

	self.powerPositionX:SetValue(Settings.Player.Vitals.Power.Position.X);
	self.powerPositionY:SetValue(Settings.Player.Vitals.Power.Position.Y);
	self.playerPowerColour:SetSelected(Settings.Player.Vitals.Power.Display);
	self.customPlayerPowerColour:SetColor(TableToColor(Settings.Player.Vitals.Power.Color));
	self.powerWidth:SetValue(Settings.Player.Vitals.Power.Size.X);
	self.powerHeight:SetValue(Settings.Player.Vitals.Power.Size.Y);

	self.nameTextFormat:SetText(Settings.Player.Vitals.Text.Format);
	self.nameTextAnchor:SetSelected(AlignmentToString(Settings.Player.Vitals.Text.Anchor));
	self.nameTextXOffset:SetValue(Settings.Player.Vitals.Text.Offset.X);
	self.nameTextYOffset:SetValue(Settings.Player.Vitals.Text.Offset.Y);
	self.nameTextColor:SetColor(TableToColor(Settings.Player.Vitals.Text.Color));
	self.nameTextScale:SetValue(Settings.Player.Vitals.Text.Scale*100);

	self.effectsBasicEnabled:SetValue(Settings.Effects.Basic.Enabled);
	self.effectsWidth:SetValue(Settings.Player.Effects.Size.X);
	self.effectsHeight:SetValue(Settings.Player.Effects.Size.Y);
	self.effectsZoom:SetValue(Settings.Player.Effects.Size.Zoom*100);

	self.stackTextAnchor:SetSelected(AlignmentToString(Settings.Player.Effects.Stack.Anchor));
	self.stackTextXOffset:SetValue(Settings.Player.Effects.Stack.Offset.X);
	self.stackTextYOffset:SetValue(Settings.Player.Effects.Stack.Offset.Y);
	self.stackTextColor:SetColor(TableToColor(Settings.Player.Effects.Stack.Color));
	self.stackTextScale:SetValue(Settings.Player.Effects.Stack.Scale*100);

	self.durationTextAnchor:SetSelected(AlignmentToString(Settings.Player.Effects.Duration.Anchor));
	self.durationTextXOffset:SetValue(Settings.Player.Effects.Duration.Offset.X);
	self.durationTextYOffset:SetValue(Settings.Player.Effects.Duration.Offset.Y);
	self.durationTextColor:SetColor(TableToColor(Settings.Player.Effects.Duration.Color));
	self.durationTextScale:SetValue(Settings.Player.Effects.Duration.Scale*100);

	self.targetEnabled:SetData(Settings.Target.Enabled);
	self.targetMoraleColour:SetSelected(Settings.Target.Vitals.Morale.Display);
	self.customTargetMoraleColour:SetColor(TableToColor(Settings.Target.Vitals.Morale.Color));
	self.targetTextFormat:SetText(Settings.Target.Vitals.Morale.Text.Format);
	self.targetNameFormat:SetText(Settings.Target.Vitals.Text.Format);

	self.ttkEnabled:SetData(Settings.Target.Vitals.TimeToKill.Enabled);
	self.ttkTextAnchor:SetSelected(AlignmentToString(Settings.Target.Vitals.TimeToKill.Anchor));
	self.ttkTextXOffset:SetValue(Settings.Target.Vitals.TimeToKill.Offset.X);
	self.ttkTextYOffset:SetValue(Settings.Target.Vitals.TimeToKill.Offset.Y);
	self.ttkTextColor:SetColor(TableToColor(Settings.Target.Vitals.TimeToKill.Color));
	self.ttkTextScale:SetValue(Settings.Target.Vitals.TimeToKill.Scale*100);

	self:LoadEffectSettings();
end